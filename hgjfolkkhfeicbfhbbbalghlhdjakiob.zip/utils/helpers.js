/**
 * HomeSage.ai Shared Helpers
 * Loaded as a content script and via <script> in popup/options pages.
 * Top-level function declarations are accessible as globals to subsequent scripts.
 */

/* exported escapeHtml, log */

/**
 * Escape HTML to prevent XSS.
 */
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

/**
 * Dev-mode logger. Set DEV_MODE = true in constants.js to enable.
 * All console.log/warn calls go through this — silent in production.
 */
function log(...args) {
  if (typeof DEV_MODE !== 'undefined' && DEV_MODE) console.log(...args);
}
