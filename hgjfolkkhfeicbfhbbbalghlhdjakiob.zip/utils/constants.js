/**
 * HomeSage.ai Shared Constants
 * Loaded as the first content script and via <script> in popup/options pages.
 * Uses var so declarations are accessible as globals to subsequent scripts.
 */

/* exported HOMESAGE_API_BASE_URL, HOMESAGE_REPORT_CREDITS_COST, HOMESAGE_FREE_REPORT_LIMIT, DEV_MODE */
var HOMESAGE_API_BASE_URL = 'https://developers.homesage.ai';
var HOMESAGE_REPORT_CREDITS_COST = 15;
var HOMESAGE_FREE_REPORT_LIMIT = 3;
var DEV_MODE = false;
