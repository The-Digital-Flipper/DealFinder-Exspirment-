/**
 * AddressDetectorV2 — US Address Detection
 *
 * Architecture:  3 patterns → extractAddresses() → isValidAddress()
 * DOM walk (findAddressesInDOM) is NOT included yet — added in a later step.
 *
 * Patterns
 * --------
 *   ROUTE    — route/highway addresses          state required, zip optional
 *   STREET   — standard street addresses        state required, zip optional
 *   CATCHALL — everything else with a location  state + zip both required
 */

if (typeof AddressDetectorV2 !== 'undefined') {
  // Already loaded — skip re-declaration
} else {

var AddressDetectorV2 = {

  // ─── DATA ──────────────────────────────────────────────────────────────────

  streetTypes: [
    // Tier 1 — ~85 % of US addresses
    'Street', 'St', 'Avenue', 'Ave', 'Boulevard', 'Blvd', 'Road', 'Rd',
    'Drive', 'Dr', 'Lane', 'Ln', 'Way', 'Court', 'Ct', 'Circle', 'Cir',
    'Place', 'Pl', 'Terrace', 'Ter', 'Trc',
    // Highway / Parkway
    'Highway', 'Hwy', 'Parkway', 'Pkwy', 'Freeway', 'Fwy', 'Expressway', 'Expy',
    'Turnpike', 'Tpke', 'Tpk',
    // Nature / Terrain
    'Trail', 'Trl', 'Path', 'Pass', 'Trace', 'Run', 'Creek', 'Crk',
    'Ridge', 'Rdg', 'Crest', 'Knoll', 'Knolls', 'Bluff', 'Blf',
    'Cliff', 'Glen', 'Hollow', 'Holw', 'Valley', 'Vly', 'Dale',
    'Meadow', 'Meadows', 'Grove', 'Grv',
    // Water
    'Cove', 'Harbor', 'Harbour', 'Shore', 'Shr', 'Shores', 'Beach',
    'Isle', 'Lake', 'Lk', 'Lakes', 'Lks', 'Bay', 'Bayou',
    'Springs', 'Spgs', 'Spring', 'Spg', 'Falls', 'River',
    // Shapes / Features
    'Loop', 'Bend', 'Oval', 'Square', 'Sq',
    'Crossing', 'Xing', 'Junction', 'Jct', 'Fork', 'Forks',
    'Point', 'Pt', 'Pointe',
    // Developments
    'Commons', 'Common', 'Center', 'Ctr', 'Centre',
    'Plaza', 'Plz', 'Mall', 'Park', 'Prk', 'Gardens', 'Gdns', 'Garden', 'Gdn',
    'Estates', 'Estate', 'Heights', 'Hts', 'Hills', 'Hill',
    'Village', 'Vlg', 'Vista', 'Manor', 'Mnr',
    // Other
    'Walk', 'Walks', 'Row', 'Rowe', 'Alley', 'Aly',
    'Landing', 'Lndg', 'Haven', 'Hvn', 'View', 'Vw',
    'Mount', 'Mt', 'Mission', 'Msn', 'Orchard', 'Orch',
    'Ranch', 'Rnch', 'Rest', 'Rue', 'Skyway',
    'Station', 'Sta', 'Summit', 'Smt', 'Tunnel', 'Tun',
    'Union', 'Un', 'Viaduct', 'Via', 'Ville', 'Vl',
    'Wells', 'Wls', 'Extension', 'Ext',
    'Key', 'Keys', 'Rapid', 'Rapids', 'Mill', 'Mills',
    'Passage', 'Gateway', 'Gtwy', 'Riviera',
    'Stravenue', 'Stream', 'Throughway', 'Trafficway',
    'Pike', 'Spur', 'Ramp', 'Overpass', 'Underpass',
    'Overlook', 'Flat', 'Flats', 'Green', 'Greens',
    'Camp', 'Canyon', 'Cyn', 'Cape', 'Causeway', 'Cswy',
    'Cliffs', 'Club', 'Corner', 'Corners', 'Course',
    'Coves', 'Dam', 'Divide', 'Dv', 'Ferry', 'Fry',
    'Field', 'Fld', 'Fields', 'Flds', 'Forest', 'Frst',
    'Fort', 'Ft', 'Inlet', 'Inlt', 'Island', 'Is',
    'Islands', 'Iss', 'Knolls', 'Land', 'Light', 'Lgt',
    'Lights', 'Lock', 'Locks', 'Lodge', 'Ldg', 'Loaf',
    'Manors', 'Mnrs', 'Mews', 'Motorway', 'Neck',
    'Pines', 'Plain', 'Plains', 'Port', 'Prt', 'Ports',
    'Prairie', 'Pr', 'Radial', 'Radl', 'Riv',
    'Shoal', 'Shoals', 'Terr',
    'Track', 'Trce', 'Trak', 'Trfy',
    'Valleys', 'Vlys', 'Ways',
    'Shopping Center', 'Shpg Center', 'Shopping Ctr', 'Shpg Ctr'
  ],

  stateAbbreviations: [
    'AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA',
    'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD',
    'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ',
    'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC',
    'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY', 'DC'
  ],

  // ─── PATTERN BUILDERS ──────────────────────────────────────────────────────

  _getStreetTypesFragment() {
    // Longest first so "Shopping Center" matches before "Shopping"
    return [...this.streetTypes]
      .sort((a, b) => b.length - a.length)
      .map(t => t.replace(/\s+/g, '\\s+'))
      .join('|');
  },

  _getStatesFragment() {
    return this.stateAbbreviations.join('|');
  },

  _buildPatterns() {
    const types  = this._getStreetTypesFragment();
    const states = this._getStatesFragment();

    // ── Shared building blocks ──────────────────────────────────────────────

    // House/building number — plain (123) or hyphenated range (1029-1031)
    const num = '\\d{1,6}(?:-\\d{1,6})?';

    // Optional directional prefix:  N / NW / Northeast / etc.
    const dir =
      '(?:(?:N|S|E|W|NE|NW|SE|SW|North|South|East|West|' +
      'Northeast|Northwest|Southeast|Southwest)\\.?\\s+)?';

    // Optional directional suffix after street type: "Pkwy N", "Lindbergh Dr NE"
    // Two-letter forms must come before single-letter to avoid "N" matching inside "NE".
    const dirSuffix = '(?:\\s+(?:NE|NW|SE|SW|N|S|E|W)(?=\\s|,|$))?';

    // Optional unit designator:  Apt 4B / Suite 100 / #3 / Floor 2 / etc.
    const unit =
      '(?:\\s*,?\\s*' +
      '(?:Apt\\.?|Apartment|Unit|Suite|Ste\\.?|#|Fl\\.?|Floor|' +
      'Bldg\\.?|Building|Room|Rm\\.?|No\\.?)' +
      '\\s*#?\\s*[A-Za-z0-9-]+)?';

    // City name — one or more words, letters/periods only per word, up to 5 words.
    // The negative lookahead (?!state\b) before each additional word prevents the
    // city from absorbing a state abbreviation, which would cause the regex to
    // match past the real state and find a false state later (e.g. "in" → IN).
    const cityWord = "[A-Za-z][A-Za-z\\.']*";
    const city = cityWord + '(?:\\s+(?!(?:' + states + ')\\b)' + cityWord + '){0,4}';

    // State abbreviation (required in all three patterns).
    // Word boundaries are critical — without them the regex backtracks city to
    // a short prefix and matches the state abbreviation inside the city word
    // (e.g. city="Spr" + state "IN" from "ingfield" in "Springfield").
    const state = '\\b(?:' + states + ')\\b';

    // Optional country suffix — ", USA" or ", United States" as returned by mapping APIs
    const country = '(?:,?\\s*(?:USA|United\\s+States))?';

    // ZIP code:
    //   optional — ROUTE and STREET (city + state already strong enough)
    //   required — CATCHALL (the only anchor keeping it from over-matching)
    const zipOpt = '(?:[,\\s]\\s*\\d{4,5}(?:-\\d{4})?)?' + country;
    const zipReq = '[,\\s]\\s*\\d{4,5}(?:-\\d{4})?' + country;

    // City + state + optional zip  (ROUTE, STREET)
    // Comma before city is optional — many real addresses omit it online
    const location = '\\s*,?\\s*' + city + ',?\\s*' + state + zipOpt;

    return {

      // ── ROUTE ─────────────────────────────────────────────────────────────
      //
      // Matches:
      //   3949 Route 31, Clay NY 13041
      //   25737 US Rt 11, Evans Mills NY 13637
      //   812 County Road 15, Salem NY 12865
      //   4521 SR 37, Bloomington IN 47401
      //   100 State Route 9W, Garrison NY 10524
      //
      // Route number may have a letter suffix (9W, 31A).
      ROUTE: new RegExp(
        '\\b' + num + '\\s+' +
        '(?:' +
          '(?:State\\s+)?(?:Route|Rt|RT)' + '|' +
          'US\\s+(?:Route|Rt|Hwy|Highway)' + '|' +
          'County\\s+(?:Road|Rd)'          + '|' +
          'SR|CR|I-'                        +
        ')' +
        '\\s*\\d+[A-Za-z]?' +
        unit +
        location,
        'gi'
      ),

      // ── STREET ────────────────────────────────────────────────────────────
      //
      // Matches:
      //   1247 W Oak Street, Chicago IL 60614        (directional prefix)
      //   123 42nd Street, New York NY 10001          (numbered cross-street)
      //   1847 W Diversey Pkwy N, Chicago IL 60614   (directional suffix)
      //   1029-1031 Jackson St, San Francisco CA 94133 (hyphenated range)
      //   5399 W Genesee St, Camillus NY 13031
      //
      // Street name is non-greedy [0–40 chars] so the first matching
      // street type suffix wins, not the last one on the line.
      STREET: new RegExp(
        '\\b' + num + '\\s+' +
        dir +
        '[A-Za-z0-9][A-Za-z0-9\\s\\.\'-]{0,40}?' +
        '(?:' + types + ')\\.?' +
        dirSuffix +
        unit +
        location,
        'gi'
      ),

      // ── CATCHALL ──────────────────────────────────────────────────────────
      //
      // Catches anything with state + zip that ROUTE/STREET didn't grab:
      //   843 Six Iron, San Antonio TX 78221
      //   30 Catskill, Catskill NY 12414
      //   1586 Plan, View Wood Estates, Hermiston OR 97838
      //   123 Main St, Portland, OR, 97201
      //
      // [^\n]{5,80}? — non-greedy, bounded:
      //   min 5 chars   → avoids matching bare "123 TX 78201"
      //   max 80 chars  → prevents runaway matching on long paragraphs
      //   no newline    → stays on a single line of text
      //
      // State + ZIP are both REQUIRED — they are the only anchor keeping
      // this pattern from over-matching on general text.
      CATCHALL: new RegExp(
        '\\b' + num + '\\s+' +
        '[^\\n]{5,80}?' +
        '\\s*\\b(?:' + states + ')\\b' +
        zipReq,
        'gi'
      )
    };
  },

  // ─── CACHED ACCESSORS ──────────────────────────────────────────────────────

  _cachedPatterns:               null,
  _cachedValidationTypesPattern: null,
  _cachedValidationStatePattern: null,
  _cachedStateZipPattern:        null,

  get _compiledPatterns() {
    if (!this._cachedPatterns) this._cachedPatterns = this._buildPatterns();
    return this._cachedPatterns;
  },

  get _validationTypesPattern() {
    if (!this._cachedValidationTypesPattern) {
      this._cachedValidationTypesPattern = new RegExp(
        '\\b(?:' + this.streetTypes.map(t => t.replace(/\s+/g, '\\s+')).join('|') + ')\\b',
        'i'
      );
    }
    return this._cachedValidationTypesPattern;
  },

  get _validationStatePattern() {
    if (!this._cachedValidationStatePattern) {
      this._cachedValidationStatePattern = new RegExp(
        '\\b(?:' + this.stateAbbreviations.join('|') + ')\\b'
      );
    }
    return this._cachedValidationStatePattern;
  },

  // Matches a state abbreviation immediately followed by a ZIP code —
  // used to detect complete "city, ST ZIP" lines vs. bare directionals like "NE".
  get _validationStateZipPattern() {
    if (!this._cachedStateZipPattern) {
      this._cachedStateZipPattern = new RegExp(
        '\\b(?:' + this.stateAbbreviations.join('|') + ')\\b[\\s,]*\\d{4,5}\\b'
      );
    }
    return this._cachedStateZipPattern;
  },

  // ─── PUBLIC API ────────────────────────────────────────────────────────────

  /**
   * Extract all address strings from a plain text input.
   *
   * Runs ROUTE → STREET → CATCHALL in order. Deduplicates by character
   * position: when two matches overlap, the longer one wins.
   *
   * @param  {string} text
   * @returns {Array<{text: string, index: number, length: number}>}
   */
  extractAddresses(text) {
    if (!text || text.length < 8) return [];
    if (!/\d/.test(text))          return [];

    const raw      = [];
    const patterns = this._compiledPatterns;

    for (const [, pattern] of Object.entries(patterns)) {
      pattern.lastIndex = 0;
      let match;

      while ((match = pattern.exec(text)) !== null) {

        // Reject matches where the house number is the tail of a hyphenated
        // address range.  "740-50 West Addison St" — the regex sees \b50\b
        // as a valid house number because "-" acts as a word boundary.
        // Fix: if the chars immediately before the match are "digit-", skip.
        if (match.index > 0) {
          const pre = text.slice(Math.max(0, match.index - 3), match.index);
          if (/\d-$/.test(pre)) continue;
        }

        // Trim trailing punctuation / whitespace
        const rawText = match[0].trim().replace(/[,.\s]+$/, '').trim();
        if (rawText.length < 8) continue;

        raw.push({ text: rawText, index: match.index, length: rawText.length });
      }
    }

    if (raw.length === 0) return [];

    // Validate before dedup. Without this, an invalid long match (e.g. CATCHALL
    // absorbing "3 beds … 456 Oak Ave") wins the overlap check and evicts the
    // valid shorter STREET match before the caller ever sees it.
    const valid = raw.filter(m => this.isValidAddress(m.text));
    if (valid.length === 0) return [];

    // Longest valid match wins at any overlapping position
    valid.sort((a, b) => b.length - a.length);

    const kept    = [];
    const claimed = [];

    for (const m of valid) {
      const end      = m.index + m.length;
      const overlaps = claimed.some(c => !(m.index >= c.end || end <= c.start));
      if (!overlaps) {
        kept.push(m);
        claimed.push({ start: m.index, end });
      }
    }

    // Return in left-to-right document order
    kept.sort((a, b) => a.index - b.index);
    return kept;
  },

  /**
   * Validate that a matched string is genuinely an address.
   * Rejects listing phrases, prices, real-estate card terms, and ratios.
   *
   * @param  {string} text
   * @returns {boolean}
   */
  // Alias for V1 compatibility — content.js calls findAddresses(text)
  findAddresses(text) { return this.extractAddresses(text); },

  /**
   * Collect visible text from an element, joining text nodes with spaces.
   * Prevents adjacent inline elements from being concatenated without a separator.
   * Used by content.js resolveFullAddress() to assemble parent element text.
   *
   * @param  {Element} element
   * @returns {string}
   */
  _getTextWithSpaces(element) {
    const parts = [];
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, null);
    let node;
    while ((node = walker.nextNode())) {
      const trimmed = node.textContent.trim();
      if (trimmed) parts.push(trimmed);
    }
    return parts.join(' ');
  },

  /**
   * Walk the DOM and return all addresses found in visible text nodes.
   * Phase 1 only — single text node matching, no cross-element combining.
   * Cross-element combining (Phase 2) is intentionally omitted: it produces
   * false positives by merging unrelated content (e.g. timestamps + nearby zips).
   *
   * Each result: { node, parentElement, address, normalized, index, length }
   *
   * @param  {Element} root            - Root element to search within (default: document.body)
   * @param  {Object}  options
   * @param  {boolean} options.deduplicate - Remove duplicate address strings (default: true)
   * @param  {boolean} options.strict      - Accepted for API compatibility; V2 patterns are
   *                                         already strict (state required in all patterns)
   * @returns {Array}
   */
  findAddressesInDOM(root, options) {
    if (!root) root = document.body;
    const deduplicate = !options || options.deduplicate !== false;

    const results = [];

    const walker = document.createTreeWalker(
      root,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          const parent = node.parentElement;
          if (!parent) return NodeFilter.FILTER_REJECT;

          // Skip non-visible element types
          const tag = parent.tagName.toLowerCase();
          if (['script', 'style', 'noscript', 'iframe', 'svg'].includes(tag)) {
            return NodeFilter.FILTER_REJECT;
          }

          // Skip our own injected UI
          if (parent.closest('.homesage-icon-wrapper, .homesage-permanent-icon, .homesage-popup, .homesage-sidebar')) {
            return NodeFilter.FILTER_REJECT;
          }

          // Skip elements hidden via inline style or hidden attribute
          if (parent.style && (parent.style.display === 'none' || parent.style.visibility === 'hidden')) {
            return NodeFilter.FILTER_REJECT;
          }
          if (parent.hidden) return NodeFilter.FILTER_REJECT;

          // Skip screen-reader-only elements (visually hidden but in DOM)
          const cls = (parent.className || '').toString().toLowerCase();
          if (cls.includes('visuallyhidden') || cls.includes('sr-only') ||
              cls.includes('screen-reader') || cls.includes('visually-hidden')) {
            return NodeFilter.FILTER_REJECT;
          }

          // Skip empty text nodes
          if (!node.textContent.trim()) return NodeFilter.FILTER_REJECT;

          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );

    // Partial address candidates: text nodes that start with a house number and
    // contain a street type but no state abbreviation. These are the "street line"
    // of split addresses (e.g. "248 Dalewood Way" with city/state in a sibling).
    const partials = [];

    let node;
    while ((node = walker.nextNode())) {
      const matches = this.extractAddresses(node.textContent);
      if (matches.length > 0) {
        for (const match of matches) {
          results.push({
            node:          node,
            parentElement: node.parentElement,
            address:       match.text,
            normalized:    match.text.toLowerCase().replace(/\s+/g, ' ').replace(/,/g, ''),
            index:         match.index,
            length:        match.length
          });
        }
      } else {
        // Collect partial candidates for the combining pass below.
        // Conditions: starts with a digit (house number), has a street type,
        // no state abbreviation, and short enough to be just a street line.
        const trimmed = node.textContent.trim();
        if (
          trimmed.length > 0 &&
          trimmed.length <= 60 &&
          // House number exists anywhere in the string (not just at start).
          // Handles building-name prefixes ("Humboldt | 2737 Humboldt Ave")
          // and numbered streets ("2420 9th Ave" — "9th" starts with a digit,
          // so we allow \d+(?:st|nd|rd|th) as an alternative to [A-Za-z]).
          /\b\d{1,6}\s+(?:[A-Za-z]|\d+(?:st|nd|rd|th)\b)/.test(trimmed) &&
          this._validationTypesPattern.test(trimmed) &&
          // Exclude only when the text contains a state abbreviation immediately
          // followed by a ZIP — that's a complete city/state/zip line, not a
          // street line. A bare directional like "NE" has no zip after it so it
          // won't match, preventing the house number from being mistaken for a zip.
          !this._validationStateZipPattern.test(trimmed)
        ) {
          partials.push(node);
        }
      }
    }

    // ── Targeted combining pass ─────────────────────────────────────────────
    // For each partial street-line node, find exactly ONE city/state line and
    // combine only those two — nothing else. Two strategies cover all known
    // split-address layouts:
    //
    //   Strategy A (Trulia-style): the city/state text is another text node
    //   inside the SAME parent element as the street line.
    //     <div>2242 Jernigan Dr SE<!-- -->, <br>Atlanta, GA 30315</div>
    //
    //   Strategy B (Realtor/Homes-style): the city/state text is in a SIBLING
    //   element of the street line's parent.
    //     <div class="card-address">
    //       <div class="card-address-1">248 Dalewood Way</div>
    //       <div class="card-address-2">San Francisco, CA 94127</div>
    //     </div>
    //
    // The city/state candidate must contain a state abbreviation and be ≤ 60
    // chars so we never accidentally pull in price, beds, or other card text.

    const MAX_CITYSTATE_CHARS = 60;

    for (const partialNode of partials) {
      const parent = partialNode.parentElement;
      if (!parent) continue;

      // Street line text — strip any trailing punctuation before combining
      const streetLine = partialNode.textContent.trim().replace(/[,\s]+$/, '').trim();

      let cityStateLine = null;

      // Strategy A: other text nodes within the same parent that contain a state
      const twA = document.createTreeWalker(parent, NodeFilter.SHOW_TEXT, null);
      let tn;
      while ((tn = twA.nextNode())) {
        if (tn === partialNode) continue;
        const t = tn.textContent.trim();
        if (t && t.length <= MAX_CITYSTATE_CHARS && this._validationStatePattern.test(t)) {
          cityStateLine = t;
          break;
        }
      }

      // Strategy B: sibling elements of the parent that contain a state
      if (!cityStateLine && parent.parentElement) {
        const siblings = parent.parentElement.children;
        for (let i = 0; i < siblings.length; i++) {
          if (siblings[i] === parent) continue;
          const t = siblings[i].textContent.trim();
          if (t && t.length <= MAX_CITYSTATE_CHARS && this._validationStatePattern.test(t)) {
            cityStateLine = t;
            break;
          }
        }
      }

      if (!cityStateLine) continue;

      const combined = streetLine + ', ' + cityStateLine;
      const matches = this.extractAddresses(combined);

      for (const match of matches) {
        const norm = match.text.toLowerCase().replace(/\s+/g, ' ').replace(/,/g, '');
        // Skip if Phase 1 already found this address
        if (results.some(r => r.normalized === norm)) continue;

        results.push({
          node:          partialNode,
          parentElement: parent,
          address:       match.text,
          normalized:    norm,
          index:         match.index,
          length:        match.length
        });
      }
    }

    if (!deduplicate) return results;

    // When deduplicating, keep only the first occurrence of each normalized address
    const seen = new Set();
    return results.filter(r => {
      if (seen.has(r.normalized)) return false;
      seen.add(r.normalized);
      return true;
    });
  },

  isValidAddress(text) {
    const t = text.trim();

    // Must start with a digit; street numbers are never 0
    if (!/^\d/.test(t) || /^0\s/.test(t)) return false;

    // Length bounds
    if (t.length < 8 || t.length > 150) return false;

    // Minimum three tokens:  number + street name + type
    if (t.split(/\s+/).length < 3) return false;

    // ── Rejection rules ────────────────────────────────────────────────────

    // Listing-count phrases: "474 rentals", "12 listings found", "3 results"
    if (/^\d+\s+(?:rentals?|listings?|results?|properties|homes?\s+for)\b/i.test(t)) return false;

    // Dollar amounts: "$289,900"
    if (/\$[\d,]+/.test(t)) return false;

    // Real estate card terms at the start.
    // Uses lookahead (not \b) because split-element text can concatenate
    // tokens without spaces: "3 beds1 bath900 sqft".
    if (/^\d[\d,. ]*\s*(?:sq\.?\s*ft|sqft|sq\.\s*ft|square\s*(?:ft|feet|foot)|beds?|bds?|bd|baths?|ba|half\s*baths?|garage|car)(?=[\s,\d]|$)/i.test(t)) return false;

    // Ratio / comparison phrases: "4 out of 5", "1 of every 3"
    if (/^\d+\s+(?:out\s+of|of\s+every|in\s+every)\s+\d/i.test(t)) return false;

    // Real estate card terms anywhere in the string (not just at start).
    // Catches combined text like "123 Main St, 3 beds, 2 baths TX 12345".
    // Uses plural forms only — "beds"/"baths" are unambiguous listing terms anywhere.
    // Singular "bath" is excluded here because "1 Bath Rd" is a valid street name.
    if (/\b\d+\s*(?:beds|bds|baths|sqft|sq\.?\s*ft)\b/i.test(t)) return false;

    // ── Signal detection ───────────────────────────────────────────────────

    if (!t.includes(',')) return false;

    const hasStreetType     = this._validationTypesPattern.test(t);
    const hasRoute          = /\b(?:Route|Rt|RT|SR|CR|I-|US\s+(?:Rt|Route|Hwy))\b/i.test(t);
    const hasNumberedStreet = /\d+(?:st|nd|rd|th)\b/i.test(t);
    const hasStateAbbr      = this._validationStatePattern.test(t);
    const hasZip            = /\b\d{4,5}(?:-\d{4})?\b/.test(t);

    if (hasStreetType || hasRoute || hasNumberedStreet || (hasStateAbbr && hasZip)) return true;

    return false;
  }

};

if (typeof window !== 'undefined') window.AddressDetectorV2 = AddressDetectorV2;

// Alias so content.js can reference AddressDetector (the V1 name) unchanged.
var AddressDetector = AddressDetectorV2;

} // end guard
