/**
 * HomeSage.ai Options Page Script
 */

(function() {
  'use strict';

  const radioButtons = document.querySelectorAll('input[name="displayMode"]');
  const saveStatus = document.getElementById('save-status');
  let saveTimeout;

  function openPage(path) {
    chrome.tabs.create({ url: `${HOMESAGE_API_BASE_URL}${path}` });
  }

  function showToast(message) {
    let toast = document.getElementById('options-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'options-toast';
      toast.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#1f2937;color:#fff;padding:10px 20px;border-radius:8px;font-size:13px;z-index:9999;max-width:340px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,0.3);transition:opacity 0.2s;';
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.style.display = 'block';
    toast.style.opacity = '1';
    clearTimeout(toast._hideTimer);
    toast._hideTimer = setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => { toast.style.display = 'none'; }, 200); }, 4000);
  }

  /**
   * Initialize options page
   */
  async function init() {
    // Load saved preference
    const result = await chrome.storage.local.get(['displayMode']);
    const savedMode = result.displayMode || 'permanent';

    // Set the correct radio button
    radioButtons.forEach(radio => {
      radio.checked = radio.value === savedMode;
    });

    // Set up change listeners
    radioButtons.forEach(radio => {
      radio.addEventListener('change', handleModeChange);
    });

    // Set up button listeners
    setupButtonListeners();

    // Set up favorites collapsible
    setupFavoritesCollapsible();

    // Sync favorites when returning to this tab (e.g. after adding/removing on platform)
    setupFavoritesAutoSync();

    // Sync favorites with server, then load
    try {
      await chrome.runtime.sendMessage({ action: 'syncFavorites' });
    } catch (error) {
      log('[HomeSage Options] Favorites sync skipped:', error.message);
    }
    await loadFavorites();

    // Load account and usage data
    await loadAccountData();

    // Populate version from manifest
    const manifest = chrome.runtime.getManifest();
    const versionEl = document.getElementById('extension-version');
    if (versionEl) versionEl.textContent = manifest.version;
  }

  // Track login state
  let isLoggedIn = false;

  /**
   * Set up button click listeners
   */
  function setupButtonListeners() {
    // Auth button (login/logout)
    document.getElementById('auth-btn')?.addEventListener('click', async () => {
      if (isLoggedIn) {
        // Logout - clear the auth cookie first
        try {
          await chrome.cookies.remove({
            url: HOMESAGE_API_BASE_URL,
            name: 'id_token'
          });
          log('[HomeSage Options] Cookie cleared');
        } catch (e) {
          log('[HomeSage Options] Cookie clear failed:', e);
        }
        // Clear local storage data
        await chrome.storage.local.remove(['freeUsage']);
        // Reload the options page to reflect logged-out state
        location.reload();
      } else {
        // Login
        openPage('/login');
      }
    });

    // Upgrade link
    document.getElementById('upgrade-link')?.addEventListener('click', (e) => {
      e.preventDefault();
      openPage('/subscription');
    });

    // Purchase credits link
    document.getElementById('purchase-link')?.addEventListener('click', (e) => {
      e.preventDefault();
      openPage('/subscription');
    });

    // Usage login link
    document.getElementById('usage-login-link')?.addEventListener('click', (e) => {
      e.preventDefault();
      openPage('/login');
    });
  }

  /**
   * Load account and usage data
   */
  async function loadAccountData() {
    try {
      // Check authentication
      const authResult = await chrome.runtime.sendMessage({ action: 'checkAuth' });
      
      if (!authResult || !authResult.authenticated) {
        showLoggedOutState();
        hideUsageSection();
        return;
      }

      // Show logged in state
      showLoggedInState(authResult.user);

      // Check subscription
      const subResult = await chrome.runtime.sendMessage({ action: 'checkSubscription' });
      
      if (subResult && subResult.success) {
        if (subResult.hasSubscription) {
          showPaidUsage(subResult);
        } else if (subResult.isFreeUser) {
          showFreeUsage(subResult);
        } else if (subResult.isExpired) {
          showUsageError('Your subscription has expired.');
        } else {
          showUsageError('Unable to load usage data.');
        }
      } else {
        showUsageError(subResult?.error || 'Unable to load usage data. Please try again later.');
      }

    } catch (error) {
      console.error('[HomeSage Options] Error loading account data:', error);
      showLoggedOutState();
      hideUsageSection();
    }
  }

  /**
   * Show logged in state
   */
  function showLoggedInState(user) {
    isLoggedIn = true;

    // Update email
    const emailEl = document.getElementById('account-email');
    if (emailEl && user?.email) {
      emailEl.textContent = user.email;
    } else if (emailEl) {
      emailEl.textContent = 'Logged in';
    }

    // Update auth button to logout
    const authBtn = document.getElementById('auth-btn');
    if (authBtn) {
      authBtn.textContent = 'Log Out';
      authBtn.classList.remove('btn-primary');
      authBtn.classList.add('btn-secondary');
    }
  }

  /**
   * Show logged out state
   */
  function showLoggedOutState() {
    isLoggedIn = false;

    // Update email
    const emailEl = document.getElementById('account-email');
    if (emailEl) {
      emailEl.textContent = 'Not logged in';
    }

    // Update account type
    const typeEl = document.getElementById('account-type');
    if (typeEl) {
      typeEl.textContent = '';
    }

    // Update auth button to login
    const authBtn = document.getElementById('auth-btn');
    if (authBtn) {
      authBtn.textContent = 'Log In';
      authBtn.classList.remove('btn-secondary');
      authBtn.classList.add('btn-primary');
    }
  }

  /**
   * Show free user usage
   */
  function showFreeUsage(data) {
    document.getElementById('usage-loading')?.classList.add('hidden');
    document.getElementById('paid-usage')?.classList.add('hidden');
    document.getElementById('free-usage')?.classList.remove('hidden');
    clearUsageMessages();

    const limit = data.freeReportsLimit ?? HOMESAGE_FREE_REPORT_LIMIT;
    const remaining = data.freeReportsRemaining ?? limit;
    const used = limit - remaining;
    const remainingEl = document.getElementById('free-reports-remaining');
    const barEl = document.getElementById('free-usage-bar');

    if (remainingEl) remainingEl.textContent = remaining;
    // Progress bar shows how much is used (filled = used)
    if (barEl) barEl.style.width = `${(used / limit) * 100}%`;

    // Update account type
    const typeEl = document.getElementById('account-type');
    if (typeEl) typeEl.textContent = 'Free Account';
  }

  /**
   * Show paid user usage
   */
  function showPaidUsage(data) {
    document.getElementById('usage-loading')?.classList.add('hidden');
    document.getElementById('free-usage')?.classList.add('hidden');
    document.getElementById('paid-usage')?.classList.remove('hidden');
    clearUsageMessages();

    const credits = data.remainingCredits || 0;
    const creditsEl = document.getElementById('credits-balance');

    if (creditsEl) creditsEl.textContent = credits.toLocaleString();

    // Update account type
    const typeEl = document.getElementById('account-type');
    if (typeEl) typeEl.textContent = 'Pro Account';
  }

  /**
   * Hide usage section when not logged in
   */
  function hideUsageSection() {
    document.getElementById('usage-loading')?.classList.add('hidden');
    document.getElementById('free-usage')?.classList.add('hidden');
    document.getElementById('paid-usage')?.classList.add('hidden');
    clearUsageMessages();
    
    // Show a message with login link
    const usageSection = document.getElementById('usage-section');
    if (usageSection) {
      const msg = document.createElement('p');
      msg.className = 'setting-description login-prompt';
      msg.innerHTML = '<a href="#" id="usage-login-link">Log in</a> to view your usage.';
      usageSection.appendChild(msg);
      
      // Add click listener for the login link
      msg.querySelector('#usage-login-link')?.addEventListener('click', (e) => {
        e.preventDefault();
        openPage('/login');
      });
    }
  }

  /**
   * Show usage error message (when logged in but subscription check fails)
   */
  function showUsageError(message) {
    document.getElementById('usage-loading')?.classList.add('hidden');
    document.getElementById('free-usage')?.classList.add('hidden');
    document.getElementById('paid-usage')?.classList.add('hidden');
    clearUsageMessages();

    const usageSection = document.getElementById('usage-section');
    if (usageSection) {
      const msg = document.createElement('p');
      msg.className = 'setting-description usage-error-msg';
      msg.textContent = message;
      usageSection.appendChild(msg);
    }
  }

  /**
   * Clear any dynamic usage messages
   */
  function clearUsageMessages() {
    const usageSection = document.getElementById('usage-section');
    if (usageSection) {
      usageSection.querySelectorAll('.login-prompt, .usage-error-msg').forEach(el => el.remove());
    }
  }

  /**
   * Handle display mode change
   */
  async function handleModeChange(event) {
    const newMode = event.target.value;

    // Save to storage
    await chrome.storage.local.set({ displayMode: newMode });

    // Show save confirmation
    showSaveStatus();

    log('[HomeSage] Display mode changed to:', newMode);
  }

  /**
   * Show save status message
   */
  function showSaveStatus() {
    // Clear any existing timeout
    if (saveTimeout) {
      clearTimeout(saveTimeout);
    }

    // Show status
    saveStatus.classList.add('visible');

    // Hide after 2 seconds
    saveTimeout = setTimeout(() => {
      saveStatus.classList.remove('visible');
    }, 2000);
  }

  // ==================== FAVORITES ====================

  /**
   * Set up favorites collapsible
   */
  function setupFavoritesCollapsible() {
    const header = document.getElementById('favorites-header');
    const content = document.getElementById('favorites-content');

    if (header && content) {
      header.addEventListener('click', () => {
        header.classList.toggle('expanded');
        content.classList.toggle('expanded');
      });
    }
  }

  // True while a server DELETE is in flight — prevents the visibilitychange sync
  // from overwriting local storage (which would restore the just-deleted item).
  let deletionInProgress = false;

  /**
   * Sync favorites from server when user returns to the settings tab.
   * Keeps the list in sync if they added/removed saved properties on the platform.
   */
  function setupFavoritesAutoSync() {
    document.addEventListener('visibilitychange', async () => {
      if (document.visibilityState !== 'visible') return;
      // Don't let a background sync overwrite a deletion that is still in flight.
      if (deletionInProgress) return;
      try {
        await chrome.runtime.sendMessage({ action: 'syncFavorites' });
        await loadFavorites();
      } catch (error) {
        log('[HomeSage Options] Favorites auto-sync skipped:', error.message);
      }
      // Refresh account data on tab focus (replaces the separate listener that was here before)
      loadAccountData().catch(e => log('[HomeSage Options] Account data refresh skipped:', e.message));
    });
  }

  /**
   * Load and display favorites
   */
  async function loadFavorites() {
    const result = await chrome.storage.local.get(['favorites']);
    const favorites = result.favorites || [];
    
    renderFavorites(favorites);
  }

  /**
   * Render favorites list
   */
  function renderFavorites(favorites) {
    const listEl = document.getElementById('favorites-list');
    const noFavoritesEl = document.getElementById('no-favorites');
    const countEl = document.getElementById('favorites-count');

    if (!listEl) return;

    // Update count
    if (countEl) {
      countEl.textContent = `(${favorites.length})`;
    }

    // Show/hide appropriate elements
    if (favorites.length === 0) {
      listEl.innerHTML = '';
      listEl.style.display = 'none';
      if (noFavoritesEl) noFavoritesEl.style.display = 'flex';
      return;
    }

    listEl.style.display = 'block';
    if (noFavoritesEl) noFavoritesEl.style.display = 'none';

    // Render list
    listEl.innerHTML = favorites.map((fav, index) => `
      <div class="favorite-item" data-index="${index}">
        <div class="favorite-address">
          <svg class="favorite-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
            <circle cx="12" cy="10" r="3"></circle>
          </svg>
          <span>${escapeHtml(fav.address)}</span>
        </div>
        <div class="favorite-actions">
          <button class="btn-fpr" data-address="${escapeHtml(fav.address)}" title="Run Full Property Report">
            FPR
          </button>
          <button class="btn-unfavorite" data-address="${escapeHtml(fav.address)}" title="Remove from favorites">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
      </div>
    `).join('');

    // Add event listeners
    listEl.querySelectorAll('.btn-fpr').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const address = e.currentTarget.dataset.address;
        openReportPage(address);
      });
    });

    listEl.querySelectorAll('.btn-unfavorite').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const address = e.currentTarget.dataset.address;
        await removeFavorite(address);
      });
    });
  }

  /**
   * Remove a favorite (local + server sync)
   */
  async function removeFavorite(address) {
    const result = await chrome.storage.local.get(['favorites']);
    const favorites = result.favorites || [];

    const normalized = address.toLowerCase().trim();
    const removedFav = favorites.find(fav =>
      fav.address.toLowerCase().trim() === normalized
    );

    const newFavorites = favorites.filter(fav =>
      fav.address.toLowerCase().trim() !== normalized
    );

    // Optimistically remove from local storage and re-render immediately.
    await chrome.storage.local.set({ favorites: newFavorites });
    renderFavorites(newFavorites);

    // Guard the visibilitychange sync so it doesn't restore the item before the
    // server DELETE completes.
    deletionInProgress = true;
    try {
      // The DELETE endpoint uses property_id as its URL lookup field, not the
      // auto-increment saved-record id.  Always prefer property_id.
      const deleteId = removedFav?.property_id || removedFav?.saved_id;

      if (!deleteId) {
        // No server ID available — cannot DELETE from platform.  Roll back locally
        // so the UI stays consistent with server state after the next sync.
        log('[HomeSage Options] No saved_id/property_id for favorite — cannot remove from server:', address);
        await chrome.storage.local.set({ favorites });
        renderFavorites(favorites);
        showToast('Could not remove from server: missing record ID. Please try again from the platform.');
        return;
      }

      const removeResult = await chrome.runtime.sendMessage({ action: 'removeFavorite', propertyId: deleteId });

      if (removeResult?.success) {
        log('[HomeSage Options] Removed favorite from server:', address);
      } else {
        // Server DELETE failed — roll back local state so we stay in sync.
        log('[HomeSage Options] Server DELETE failed, rolling back local state:', removeResult?.error);
        await chrome.storage.local.set({ favorites });
        renderFavorites(favorites);
        showToast('Failed to remove favorite: ' + (removeResult?.error || 'Please try again.'));
      }
    } catch (error) {
      // Network/runtime error — roll back.
      console.error('[HomeSage Options] Error removing favorite from server:', error);
      await chrome.storage.local.set({ favorites });
      renderFavorites(favorites);
      showToast('Failed to remove favorite. Please check your connection and try again.');
    } finally {
      deletionInProgress = false;
    }
  }

  /**
   * Open report page for address (with credit check)
   */
  async function openReportPage(address) {
    try {
      // Check if user is authenticated
      const authResult = await chrome.runtime.sendMessage({ action: 'checkAuth' });
      
      if (!authResult || !authResult.authenticated) {
        showToast('Please log in to run a Full Property Report.');
        openPage('/login');
        return;
      }

      // Check subscription status
      const subResult = await chrome.runtime.sendMessage({ action: 'checkSubscription' });
      log('[HomeSage Options] Subscription check for FPR:', subResult);

      if (!subResult || !subResult.success) {
        showToast('Unable to verify subscription. Please try again.');
        return;
      }

      // Handle paid users - check credits (HOMESAGE_REPORT_CREDITS_COST credits per extension report)
      if (subResult.hasSubscription) {
        if (subResult.remainingCredits < HOMESAGE_REPORT_CREDITS_COST) {
          showToast(`Insufficient credits. You need ${HOMESAGE_REPORT_CREDITS_COST} credits but have ${subResult.remainingCredits}.`);
          openPage('/subscription');
          return;
        }
        log('[HomeSage Options] Paid user with sufficient credits, opening report...');
      }
      
      // Handle free users - check remaining reports
      if (subResult.isFreeUser) {
        if (subResult.freeReportsRemaining <= 0) {
          showToast(`Monthly limit reached. You've used all ${HOMESAGE_FREE_REPORT_LIMIT} free reports this month.`);
          openPage('/subscription');
          return;
        }
        log('[HomeSage Options] Free user, proceeding with report...');
      }

      // All checks passed - generate token and open report page.
      // Pass freeUser flag so background.js increments usage only after the tab opens successfully.
      const reportResult = await chrome.runtime.sendMessage({
        action: 'runReport',
        address: address,
        freeUser: subResult.isFreeUser === true
      });

      if (!reportResult || !reportResult.success) {
        console.error('[HomeSage Options] Report generation failed:', reportResult?.error);
        showToast('Failed to generate report: ' + (reportResult?.error || 'Please try again.'));
        return;
      }

      // Refresh usage display after a successful free report
      if (subResult.isFreeUser) {
        await loadAccountData();
      }

    } catch (error) {
      console.error('[HomeSage Options] Error opening report:', error);
      showToast('An error occurred. Please try again.');
    }
  }

  // Initialize on load
  document.addEventListener('DOMContentLoaded', init);


})();
