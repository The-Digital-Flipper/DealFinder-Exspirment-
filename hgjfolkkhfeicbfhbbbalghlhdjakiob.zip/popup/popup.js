/**
 * HomeSage.ai Popup Script
 * Simple address entry popup for browser toolbar
 */

(function() {
  'use strict';

  // DOM Elements
  const states = {
    addressEntry: document.getElementById('address-entry'),
    notFound: document.getElementById('not-found'),
    loginRequired: document.getElementById('login-required'),
    limitReached: document.getElementById('limit-reached'),
    insufficientCredits: document.getElementById('insufficient-credits'),
    subscriptionExpired: document.getElementById('subscription-expired'),
    loading: document.getElementById('loading'),
    error: document.getElementById('error')
  };

  const addressInput = document.getElementById('address-input');
  const creditBalance = document.getElementById('credit-balance');
  const autocompleteLoginHint = document.getElementById('autocomplete-login-hint');

  // Cached auth state — resolved once at init so the hint appears instantly on first keystroke.
  let isAuthenticated = null;
  chrome.runtime.sendMessage({ action: 'checkAuth' }, (result) => {
    isAuthenticated = result?.authenticated === true ? true
                    : result?.authenticated === false ? false
                    : null;
  });

  /**
   * Initialize popup
   */
  function init() {
    // Show address entry by default
    showState('addressEntry');
    
    // Focus on input
    addressInput?.focus();

    // Pre-fill address if one was set via the openPopupWithAddress action
    chrome.storage.local.get(['selectedAddress'], (result) => {
      if (result.selectedAddress && addressInput) {
        addressInput.value = result.selectedAddress;
        // Clear it so it doesn't persist to next open
        chrome.storage.local.remove(['selectedAddress']);
      }
    });

    // Set up event listeners
    setupEventListeners();
  }

  /**
   * Show a specific state, hide others
   */
  function showState(stateName) {
    Object.keys(states).forEach(key => {
      if (states[key]) {
        states[key].classList.toggle('hidden', key !== stateName);
      }
    });

  }

  /**
   * Set up event listeners
   */
  function setupEventListeners() {
    // Settings button
    document.getElementById('settings-btn')?.addEventListener('click', () => {
      chrome.runtime.openOptionsPage();
    });

    // Search button
    document.getElementById('search-btn')?.addEventListener('click', handleRunReport);

    // Enter key in address input
    addressInput?.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        hideAutocomplete();
        handleRunReport();
      }
    });

    // Autocomplete on input
    // Autocomplete login hint link
    document.getElementById('autocomplete-login-link')?.addEventListener('click', (e) => {
      e.preventDefault();
      openHomeSagePage('/login');
    });

    let acDebounce = null;
    addressInput?.addEventListener('input', (e) => {
      const value = e.target.value.trim();
      if (acDebounce) clearTimeout(acDebounce);
      if (value.length < 3) {
        hideAutocomplete();
        autocompleteLoginHint?.classList.add('hidden');
        return;
      }
      if (isAuthenticated === false) {
        autocompleteLoginHint?.classList.remove('hidden');
        return;
      }
      autocompleteLoginHint?.classList.add('hidden');
      acDebounce = setTimeout(() => fetchAutocomplete(value), 300);
    });

    // Hide autocomplete when clicking outside
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.autocomplete-wrapper')) {
        hideAutocomplete();
      }
    });

    // Try manual button (from not found state)
    document.getElementById('try-manual-btn')?.addEventListener('click', () => {
      showState('addressEntry');
      addressInput?.focus();
    });

    // Login button
    document.getElementById('login-btn')?.addEventListener('click', () => {
      openHomeSagePage('/login');
    });

    // Signup link
    document.getElementById('signup-link')?.addEventListener('click', (e) => {
      e.preventDefault();
      openHomeSagePage('/signup');
    });

    // Upgrade button
    document.getElementById('upgrade-btn')?.addEventListener('click', () => {
      openHomeSagePage('/subscription');
    });

    // Purchase credits button
    document.getElementById('purchase-btn')?.addEventListener('click', () => {
      openHomeSagePage('/subscription');
    });

    // Renew subscription button
    document.getElementById('renew-btn')?.addEventListener('click', () => {
      openHomeSagePage('/subscription');
    });

    // Retry button
    document.getElementById('retry-btn')?.addEventListener('click', () => {
      showState('addressEntry');
      addressInput?.focus();
    });
  }

  /**
   * Handle Run Report button click
   * Checks auth and subscription/credits before redirecting
   */
  async function handleRunReport() {
    const address = addressInput?.value.trim();
    
    if (!address) {
      addressInput?.focus();
      return;
    }

    showState('loading');

    try {
      // Check if user is authenticated
      const authResult = await chrome.runtime.sendMessage({ action: 'checkAuth' });
      
      if (!authResult || !authResult.authenticated) {
        showState('loginRequired');
        return;
      }

      // Check subscription status
      const subResult = await chrome.runtime.sendMessage({ action: 'checkSubscription' });
      log('[HomeSage Popup] Subscription check:', subResult);

      // Handle subscription check failure
      if (!subResult || !subResult.success) {
        console.error('[HomeSage Popup] Subscription check failed:', subResult?.error);
        showState('error');
        return;
      }

      // Handle expired subscription
      if (subResult.isExpired) {
        log('[HomeSage Popup] Subscription expired');
        showState('subscriptionExpired');
        return;
      }

      // Handle paid users - check if they have enough credits (15 credits per extension report)
      if (subResult.hasSubscription) {
        if (subResult.remainingCredits < HOMESAGE_REPORT_CREDITS_COST) {
          if (creditBalance) creditBalance.textContent = Number(subResult.remainingCredits).toLocaleString();
          showState('insufficientCredits');
          return;
        }
        log('[HomeSage Popup] Paid user with sufficient credits, redirecting...');
        openReportPage(address);
        return;
      }
      
      // Handle free users
      if (subResult.isFreeUser) {
        if (subResult.freeReportsRemaining <= 0) {
          showState('limitReached');
          return;
        }
        log('[HomeSage Popup] Free user, redirecting (background will increment usage)...');
        openReportPage(address, true);
        return;
      }

      // Unknown user state - show error
      console.error('[HomeSage Popup] Unknown subscription state:', subResult);
      showState('error');
      
    } catch (error) {
      console.error('[HomeSage Popup] Error:', error);
      showState('error');
    }
  }

  /**
   * Open HomeSage.ai page
   */
  function openHomeSagePage(path) {
    chrome.tabs.create({ url: HOMESAGE_API_BASE_URL + path });
  }

  /**
   * Open report page with address - generates token via API
   */
  async function openReportPage(address, freeUser = false) {
    try {
      const result = await chrome.runtime.sendMessage({ action: 'runReport', address, freeUser });
      
      if (!result || !result.success) {
        // Show "not found" state if property wasn't in database
        if (result?.error && result.error.toLowerCase().includes('not found')) {
          log('[HomeSage Popup] Address not found in database');
          showState('notFound');
        } else {
          log('[HomeSage Popup] Report generation failed:', result?.error);
          showState('error');
        }
        return;
      }
      
      // Close popup - tab is already opened by background script
      window.close();
    } catch (error) {
      console.error('[HomeSage Popup] Error generating report:', error);
      showState('error');
    }
  }

  // ==================== AUTOCOMPLETE ====================

  const acDropdown = document.getElementById('autocomplete-dropdown');

  async function fetchAutocomplete(input) {
    try {
      const response = await chrome.runtime.sendMessage({ action: 'autoComplete', input });
      if (response?.success && response.results?.length > 0) {
        showAutocomplete(response.results);
      } else {
        hideAutocomplete();
      }
    } catch (e) {
      hideAutocomplete();
    }
  }

  function showAutocomplete(results) {
    if (!acDropdown) return;
    acDropdown.innerHTML = results.map(item => {
      const text = typeof item === 'string' ? item : (item.description || item.address || item.text || JSON.stringify(item));
      return `<div class="autocomplete-item" title="${escapeHtml(text)}">${escapeHtml(text)}</div>`;
    }).join('');

    acDropdown.classList.remove('hidden');

    acDropdown.querySelectorAll('.autocomplete-item').forEach(el => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        addressInput.value = el.textContent;
        hideAutocomplete();
        addressInput.focus();
      });
    });
  }

  function hideAutocomplete() {
    if (acDropdown) {
      acDropdown.innerHTML = '';
      acDropdown.classList.add('hidden');
    }
  }

  // Initialize on load
  document.addEventListener('DOMContentLoaded', init);
})();
