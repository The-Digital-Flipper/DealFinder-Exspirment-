// This is Claude
/**
 * HomeSage.ai Content Script
 * Runs on all web pages to detect addresses and inject icons
 */

// Global error suppression for "Extension context invalidated" errors.
// When the extension is restarted/updated, old content script callbacks and
// event handlers fire in a dead context. These errors are harmless (the new
// script takes over) but pollute the error console. Suppress them globally.
if (!window.__homesageErrorHandlerInstalled) {
  window.__homesageErrorHandlerInstalled = true;

  window.addEventListener('error', (event) => {
    if (event.message?.includes('Extension context invalidated')) {
      event.preventDefault();
      event.stopImmediatePropagation();
      return true;
    }
  });

  window.addEventListener('unhandledrejection', (event) => {
    if (event.reason?.message?.includes('Extension context invalidated')) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  });
}

(function() {
  'use strict';

  // Prevent double initialization
  if (window.__homesageInitialized) return;
  window.__homesageInitialized = true;

  // State
  let displayMode = 'permanent'; // 'inline', 'permanent', 'sidebar', 'rightclick'
  let detectedAddresses = [];
  let activeIcon = null;
  let activePopup = null;
  let popupAnchorIcon = null; // permanent icon hidden while its popup is open
  let sidebarElement = null;
  let hoverTimeout = null;
  let scanIntervalId = null;
  let zillowIconIntervalId = null;
  let zillowScrollIntervalId = null;
  let clickOutsideRegistered = false;
  const trackedScrollContainers = [];
  let onScrollHandler = null;
  let ongoingSetup = false;
  let domObserver = null;
  const scrollAttached = new WeakSet();

  // Configuration
  const HOVER_DELAY = 300; // ms before showing icon
  const ICON_URL = chrome.runtime.getURL('icons/icon48.png');
  // HOMESAGE_API_BASE_URL and HOMESAGE_REPORT_CREDITS_COST are provided as globals by utils/constants.js

  // ==================== SITE DETECTION ====================
  // Computed once at load — replaces repeated window.location.hostname.includes() calls.
  const SITE = (() => {
    const h = window.location.hostname;
    const isZillow  = h.includes('zillow.com');
    const isRedfin  = h.includes('redfin.com');
    const isHomes   = h.includes('homes.com');
    const isTrulia  = h.includes('trulia.com');
    const isRealtor = h.includes('realtor.com');
    return {
      isZillow, isRedfin, isHomes, isTrulia, isRealtor,
      // homes.com homepage has two-row address cards with a card-level link wrapping both rows.
      isHomesHomepage: isHomes && (window.location.pathname === '/' || window.location.pathname === ''),
      // Redfin, Homes, Realtor: card/link overlay intercepts mouse events on our icons.
      // Needs a mousedown stopper and a mousemove hit-test to create the hover overlay.
      needsMousedownBlock:   isRedfin || isHomes || isRealtor,
      needsMousemoveOverlay: isRedfin || isHomes || isRealtor,
      // Zillow and Trulia use fast timing — both lazy-load cards dynamically.
      observerDebounce: (isZillow || isTrulia) ? 250 : 600,
      scrollDelay:      isZillow ? 100 : 300,
      // Icon block-display margin. null = use inline (default CSS). Homes is 1px; others 2px.
      iconBlockMargin: isHomes ? '1px' : (isZillow || isRedfin || isTrulia) ? '2px' : null,
    };
  })();

  // ==================== SITE ADAPTERS ====================
  // Each adapter encapsulates one site's icon insertion point and element filter.
  // getInsertionPoint(textNode) → { parent, insertBefore } | null (null = use generic fallback)
  // shouldAddIcon(targetElement) → boolean | null (null = no site-specific filter)
  const siteAdapters = {

    // ── Zillow ────────────────────────────────────────────────────────────────
    // Address is in <address> nested inside an <a> or <div>. Icon goes after the parent.
    zillow: {
      getInsertionPoint(textNode) {
        const checkEl = textNode.nodeType === Node.TEXT_NODE ? textNode.parentElement : textNode;

        // Preferred: find <address> ancestor, insert after its parent (the link <a>)
        const addressTag = checkEl?.closest?.('address');
        if (addressTag) {
          const addressParent = addressTag.parentElement;
          if (addressParent?.parentNode) {
            return { parent: addressParent.parentNode, insertBefore: addressParent.nextSibling };
          }
          // <address> directly at top level — insert after it
          if (addressTag.parentNode) {
            return { parent: addressTag.parentNode, insertBefore: addressTag.nextSibling };
          }
        }

        // Fallback: find property-card-address-link and insert after it
        const addressLink = checkEl?.closest?.('[data-test="property-card-address-link"], [data-testid="property-card-address-link"]');
        if (addressLink?.parentNode) {
          return { parent: addressLink.parentNode, insertBefore: addressLink.nextSibling };
        }

        return null;
      },
      // Guard against icons landing in inventory/stats elements (e.g. "1bd", "2ba" spans).
      // Phase 2 can pin an adjacent card's address to the wrong text node when a shared
      // container spans multiple listing cards and a low street number (e.g. "1") matches
      // a bedroom count first. Only allow icon insertion when the target element is inside
      // an <address> tag or the address-link <a>.
      shouldAddIcon(el) {
        return !!el.closest('address, [data-test="property-card-address-link"], [data-testid="property-card-address-link"], [data-c11n-component^="PropertyCard"]');
      },
    },

    // ── Redfin ────────────────────────────────────────────────────────────────
    // Address inside <a href*="/home"> or <a href*="/apartment">. Icon placed after the link.
    redfin: {
      getInsertionPoint(textNode) {
        const checkEl = textNode.nodeType === Node.TEXT_NODE ? textNode.parentElement : textNode;
        const parentA = checkEl?.closest?.('a');
        if (parentA && parentA.parentNode) {
          return { parent: parentA.parentNode, insertBefore: parentA.nextSibling };
        }
        return null;
      },
      shouldAddIcon(el) {
        return !!el.closest('a[href*="/home"], a[href*="/apartment"]');
      },
    },

    // ── Homes.com ─────────────────────────────────────────────────────────────
    // Address split across <address>/div.address lines. Icon placed after the last part in the
    // card. One icon per card (deduplication by card, not by individual address element).
    homes: {
      getInsertionPoint(textNode) {
        const checkEl = textNode.nodeType === Node.TEXT_NODE ? textNode.parentElement : textNode;
        const addressContainer = checkEl?.closest?.('address, div.address, [class*="address"]');
        if (!addressContainer) return null;

        // Homepage-specific: two-row address cards have a card-level <a> wrapping both
        // .address rows. Following that link puts the icon outside/below the card.
        // Instead, append inside the first div.address row so it stays visible.
        if (SITE.isHomesHomepage) {
          const contentContainer = addressContainer.closest('.content-container, [class*="content-container"]');
          if (contentContainer) {
            const firstRow = contentContainer.querySelector('div.address');
            if (firstRow) return { parent: firstRow, insertBefore: null };
          }
        }

        // If the address is inside a property link <a>, insert AFTER the link (not inside it).
        // This prevents the icon from moving with the card image on hover.
        const linkA = addressContainer.closest('a[href]');
        if (linkA?.parentNode) {
          // Placard cards (e.g. discovery pages): some cards have variable-height header
          // elements inside the link (e.g. "Coming Soon" banners) that push the icon below
          // the card's clipping boundary when placed after the link. Insert inside
          // placard-address-container instead — it's always within the card's visible area.
          // The mousedown blocker + capture-phase click handler prevent link navigation.
          const placardAddrContainer = linkA.querySelector('.placard-address-container');
          if (placardAddrContainer) {
            return { parent: placardAddrContainer, insertBefore: null };
          }
          return { parent: linkA.parentNode, insertBefore: linkA.nextSibling };
        }

        // Otherwise insert directly after the address container.
        if (addressContainer.parentNode) {
          return { parent: addressContainer.parentNode, insertBefore: addressContainer.nextSibling };
        }
        return null;
      },
      shouldAddIcon(el) {
        if (!el.closest('address, div.address, [class*="address"]')) return false;
        const card = el.closest('.content-container, [class*="content-container"], [class*="property-info"], [class*="listing-card"]');
        return !card?.querySelector('.homesage-permanent-icon');
      },
    },

    // ── Trulia ────────────────────────────────────────────────────────────────
    // Address inside a link with overflow/ellipsis clip. Icon placed AFTER the link.
    // shouldAddIcon is null — address detector validation is sufficient; restricting
    // to specific href patterns misses listings that use /p/ or /homes/ URL formats.
    trulia: {
      getInsertionPoint(textNode) {
        const checkEl = textNode.nodeType === Node.TEXT_NODE ? textNode.parentElement : textNode;
        const link = checkEl?.closest?.(
          'a[data-testid="property-card-link"], a[href*="/home/"], a[href*="/homes/"], a[href*="/p/"]'
        );
        if (link && link.parentNode) {
          return { parent: link.parentNode, insertBefore: link.nextSibling };
        }
        return null;
      },
      shouldAddIcon: null,
    },

    // ── Realtor.com ───────────────────────────────────────────────────────────
    // Cards have card-address-1 (street) and card-address-2 (city/state) as sibling rows
    // inside a card-address container. Both rows have truncate-line (overflow:hidden).
    // The icon must NOT go inside either row. It always goes AFTER card-address-1
    // (between the two rows, inside card-address) so placement is consistent whether
    // the detected text node came from row 1 or row 2.
    realtor: {
      getInsertionPoint(textNode) {
        const checkEl = textNode.nodeType === Node.TEXT_NODE ? textNode.parentElement : textNode;
        const cardAddress = checkEl?.closest?.('[data-testid="card-address"]');
        if (!cardAddress) return null;

        const row1 = cardAddress.querySelector('[data-testid="card-address-1"]');

        // Type 1: text node is already inside card-address-1.
        // Return null → generic fallback inserts inline after the text node (appears to the right).
        if (row1?.contains(textNode)) return null;

        // Type 2 / row2-detected: append inside card-address-1 so the icon is inline
        // at the right side of the first row, consistent with Type 1 appearance.
        if (row1) return { parent: row1, insertBefore: null };

        // No card-address-1 (single-row card) — append inside card-address.
        return { parent: cardAddress, insertBefore: null };
      },
      shouldAddIcon(el) {
        // Deduplicate by the card-address container (covers both row siblings).
        // Without this, icons from row2 detections bypass the iconizedElements check
        // because row1 and row2 are siblings — neither contains the other.
        const cardAddress = el.closest('[data-testid="card-address"]');
        return cardAddress ? !cardAddress.querySelector('.homesage-permanent-icon') : true;
      },
    },
  };

  // Resolved once — the adapter for the current page, or null on generic pages.
  const currentAdapter = SITE.isZillow  ? siteAdapters.zillow
                       : SITE.isRedfin  ? siteAdapters.redfin
                       : SITE.isHomes   ? siteAdapters.homes
                       : SITE.isTrulia  ? siteAdapters.trulia
                       : SITE.isRealtor ? siteAdapters.realtor
                       : null;

  // ==================== ICON HTML HELPERS ====================

  function getSettingsSVG() {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="12" cy="12" r="3"></circle>
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
  </svg>`;
  }

  function getManualEntryHTML() {
    return `
    <label>Property Address</label>
    <div class="homesage-autocomplete-wrapper">
      <input type="text" id="homesage-address-input" placeholder="123 Main St, City, ST 12345" autocomplete="off" />
      <div class="homesage-autocomplete-dropdown" style="display: none;"></div>
    </div>
    <button class="homesage-popup-btn homesage-btn-primary" id="homesage-search-btn">
      Run Full Property Report
    </button>
    <button class="homesage-popup-btn homesage-btn-link" id="homesage-back-btn">
      ← Back
    </button>
    `;
  }

  /**
   * Returns the icon inner HTML. On Redfin the icon is inserted inside the address
   * link (so the link receives events); logo stays a plain img (no nested links).
   */
  function getIconInnerHTML() {
    const logoImg = `<img src="${ICON_URL}" class="homesage-permanent-logo" alt="HomeSage" title="Look up on HomeSage.ai" />`;
    const settingsPart = `
        <a href="#" class="homesage-permanent-settings" title="Settings">
          ${getSettingsSVG()}
        </a>
    `;
    return logoImg + '\n      ' + settingsPart.trim();
  }

  /**
   * Safe wrapper for chrome.runtime.sendMessage
   * Handles "Extension context invalidated" and missing chrome.runtime gracefully
   */
  async function safeSendMessage(message) {
    if (typeof chrome === 'undefined' || !chrome?.runtime?.sendMessage) {
      return null;
    }
    try {
      return await chrome.runtime.sendMessage(message);
    } catch (e) {
      if (e.message?.includes('Extension context invalidated')) {
        // Silently handle — extension was restarted, new script will take over
        return null;
      }
      throw e;
    }
  }

  // Listen for messages from background script
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.action === 'openInlinePopup' && message.address) {
      log('[HomeSage] Opening inline popup for:', message.address);
      closePopup();
      openPopupCentered(message.address);
      sendResponse({ success: true });
      return true;
    }
  });

  // ==================== INITIALIZATION ====================

  /**
   * Initialize the content script
   */
  async function init() {
    // Load display mode preference
    const result = await chrome.storage.local.get(['displayMode']);
    displayMode = result.displayMode || 'permanent';

    // Capture-phase click interceptor on document (always needed)
    document.addEventListener('click', handleHomesageIconClick, true);

    // Redfin / homes.com / realtor.com: block card-level mousedown on our icons so the listing
    // card or link doesn't "steal" the interaction when the user clicks the logo.
    if (SITE.needsMousedownBlock) {
      document.addEventListener('mousedown', (e) => {
        const icon = e.target.closest?.('.homesage-permanent-icon, .homesage-icon-wrapper, .homesage-overlay-icon');
        if (!icon) return;
        e.stopPropagation();
        e.stopImmediatePropagation();
        e.preventDefault();
      }, true);
    }

    // Listen for settings changes
    try {
      chrome.storage.onChanged.addListener((changes) => {
        if (changes.displayMode) {
          displayMode = changes.displayMode.newValue;
          cleanup();
          setupDisplayMode();
        }
      });
    } catch (e) {
      // Extension context invalidated — ignore
    }

    // ==================== ICON SCANNING SYSTEM ====================

    // Central scan function — detects addresses and adds missing icons.
    function runScan() {
      const obs = domObserver;
      if (obs) obs.disconnect();

      detectAddresses();

      if (displayMode === 'permanent') {
        addMissingPermanentIcons();
      } else if (displayMode === 'sidebar') {
        updateSidebar();
      }

      if (obs) obs.observe(document.body, {
        childList: true,
        subtree: true,
        characterData: true,
        characterDataOldValue: false
      });
    }

    // --- Layer 1: EARLY SCAN ---
    function earlyQuickScan() {
      if (typeof AddressDetector === 'undefined') return;
      const earlyAddresses = AddressDetector.findAddressesInDOM(document.body, { deduplicate: false });
      if (earlyAddresses.length > 0) {
        detectedAddresses = earlyAddresses;
        log(`[HomeSage] Early scan: ${earlyAddresses.length} addresses`);
        if (displayMode === 'permanent') {
          addMissingPermanentIcons();
        } else if (displayMode === 'sidebar') {
          updateSidebar();
        }
      }
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => setTimeout(earlyQuickScan, 300), { once: true });
    } else {
      setTimeout(earlyQuickScan, 300);
    }

    // --- Layer 2: STABLE SCAN + ONGOING ---
    function setupOngoingScan() {
      if (ongoingSetup) return;
      ongoingSetup = true;
      detectAddresses();
      setupDisplayMode();
      log(`[HomeSage] Stable scan complete`);

      // MutationObserver — simple debounce, proven to work
      const observerDebounceMs = displayMode === 'permanent' ? SITE.observerDebounce : 600;
      const debouncedRunScan = debounce(runScan, observerDebounceMs);
      const observer = new MutationObserver((mutations) => {
        // Zillow: when new property cards appear (e.g. on scroll), add icons immediately
        if (SITE.isZillow && displayMode === 'permanent') {
          for (const m of mutations) {
            for (const node of m.addedNodes) {
              if (node.nodeType !== Node.ELEMENT_NODE) continue;
              const el = node;
              if (el.querySelector?.('[data-test="property-card"]') || el.matches?.('[data-test="property-card"]') ||
                  el.querySelector?.('[data-testid="property-card"]') || el.matches?.('[data-testid="property-card"]') ||
                  el.querySelector?.('[data-c11n-component^="PropertyCard"]') || el.matches?.('[data-c11n-component^="PropertyCard"]')) {
                addMissingPermanentIcons();
                break;
              }
              if (el.querySelector?.('[data-test="property-card-link"] address') || el.querySelector?.('address')) {
                addMissingPermanentIcons();
                break;
              }
            }
          }
        }
        // Trulia: when new property cards are lazily added, do a full runScan so
        // detectedAddresses is refreshed before inserting icons.
        if (SITE.isTrulia && displayMode === 'permanent') {
          for (const m of mutations) {
            for (const node of m.addedNodes) {
              if (node.nodeType !== Node.ELEMENT_NODE) continue;
              const el = node;
              if (el.querySelector?.('[data-testid="property-card-link"]') ||
                  el.matches?.('[data-testid="property-card-link"]') ||
                  el.querySelector?.('[data-testid="property-address"]') ||
                  el.matches?.('[data-testid="property-address"]')) {
                runScan();
                break;
              }
            }
          }
        }
        debouncedRunScan();
      });

      observer.observe(document.body, {
        childList: true,
        subtree: true,
        characterData: true,
        characterDataOldValue: false
      });
      domObserver = observer;

      // Scroll listener — catches virtual scrolling, infinite scroll.
      // Listen on both window AND common scroll containers, since many
      // real estate sites scroll a container div, not the window.
      let scrollTimer = null;
      const scrollDelayMs = displayMode === 'permanent' ? SITE.scrollDelay : 300;
      onScrollHandler = function onScroll() {
        removeOverlay(); // Dismiss fixed overlay when user scrolls (would otherwise stick on screen)
        if (scrollTimer) clearTimeout(scrollTimer);
        scrollTimer = setTimeout(() => runScan(), scrollDelayMs);
        if (SITE.isZillow && displayMode === 'permanent') {
          setTimeout(() => addMissingPermanentIcons(), 50);
        }
      };

      window.addEventListener('scroll', onScrollHandler, { passive: true });

      // Attach to scroll containers (Zillow list often in a scroll div; avoid double-attach)
      function attachScrollListeners() {
        const scrollContainers = document.querySelectorAll(
          '[class*="scroll"], [class*="list-content"], [class*="results"], [class*="list-card"], [class*="SearchList"], ' +
          '[style*="overflow: auto"], [style*="overflow-y: auto"], ' +
          '[style*="overflow: scroll"], [style*="overflow-y: scroll"]'
        );
        scrollContainers.forEach(el => {
          if (!scrollAttached.has(el)) {
            scrollAttached.add(el);
            el.addEventListener('scroll', onScrollHandler, { passive: true });
            trackedScrollContainers.push(el);
          }
        });
        document.querySelectorAll('div, section, main').forEach(el => {
          if (scrollAttached.has(el)) return;
          const style = window.getComputedStyle(el);
          if ((style.overflowY === 'auto' || style.overflowY === 'scroll') &&
              el.scrollHeight > el.clientHeight + 100) {
            scrollAttached.add(el);
            el.addEventListener('scroll', onScrollHandler, { passive: true });
            trackedScrollContainers.push(el);
          }
        });
      }
      setTimeout(attachScrollListeners, SITE.isZillow ? 500 : 2000);
      if (SITE.isZillow) zillowScrollIntervalId = setInterval(attachScrollListeners, 5000);

      scanIntervalId = setInterval(() => runScan(), 3000);

      if (SITE.isZillow && displayMode === 'permanent') {
        zillowIconIntervalId = setInterval(() => {
          if (displayMode === 'permanent') addMissingPermanentIcons();
        }, 800);
      }
    }

    waitForPageStable(setupOngoingScan);
    if (SITE.isZillow || SITE.isTrulia) {
      // Fallback: start scanning at 1500ms even if page hasn't stabilised yet.
      // Trulia's homepage keeps mutating during React hydration, so waitForPageStable
      // can be delayed up to 8s — this ensures the interval/observer start early.
      setTimeout(setupOngoingScan, 1500);
    }
  }

  /**
   * Wait for the page DOM to stabilize (no mutations for a sustained period).
   * Calls the callback once the page is considered "settled".
   * Has a maximum wait time to avoid waiting forever on infinite-scroll pages.
   */
  function waitForPageStable(callback) {
    let stabilityTimer = null;
    const STABILITY_THRESHOLD = 1000;  // ms of no mutations = "stable"
    const MAX_WAIT = 8000;             // max wait before giving up (8s)
    const startTime = Date.now();

    // If page already fully loaded, use a shorter threshold
    const isLoaded = document.readyState === 'complete';

    function onStable() {
      tempObserver.disconnect();
      log(`[HomeSage] Page stabilized after ${Date.now() - startTime}ms`);
      callback();
    }

    function resetTimer() {
      if (stabilityTimer) clearTimeout(stabilityTimer);
      
      // If we've waited too long, just go
      if (Date.now() - startTime > MAX_WAIT) {
        onStable();
        return;
      }

      stabilityTimer = setTimeout(onStable, isLoaded ? 800 : STABILITY_THRESHOLD);
    }

    const tempObserver = new MutationObserver(() => {
      resetTimer();
    });

    tempObserver.observe(document.body, { childList: true, subtree: true });

    // Start the timer — if no mutations happen at all, we'll fire after threshold
    resetTimer();

    // Also listen for window load as a signal
    if (!isLoaded) {
      window.addEventListener('load', () => {
        // Page loaded — give it a bit more time for post-load rendering
        setTimeout(resetTimer, 500);
      }, { once: true });
    }
  }

  /**
   * Detect all addresses on the page.
   * Uses deduplicate: false so every occurrence is listed (same address on multiple cards).
   * Required for hover mode: findAddressAtElement must match the hovered card's occurrence
   * so the icon is placed next to the right address, not the first occurrence.
   */
  function detectAddresses() {
    if (typeof AddressDetector === 'undefined') return;
    const isRealEstateSite = SITE.isZillow || SITE.isRedfin || SITE.isHomes || SITE.isTrulia || SITE.isRealtor;
    detectedAddresses = AddressDetector.findAddressesInDOM(document.body, {
      deduplicate: false,
      // On non-real-estate sites require street type + (state or ZIP) to fire.
      // Multi-line addresses combined by Phase 2 always include city/state so they pass.
      strict: !isRealEstateSite,
    });
    log(`[HomeSage] Detected ${detectedAddresses.length} addresses`);
  }

  /**
   * Set up the appropriate display mode
   */
  function setupDisplayMode() {
    switch (displayMode) {
      case 'inline':
        setupInlineMode();
        break;
      case 'permanent':
        setupPermanentMode();
        break;
      case 'sidebar':
        setupSidebarMode();
        break;
      case 'rightclick':
        setupRightClickMode();
        break;
    }
  }

  /**
   * Clean up all injected elements
   */
  function cleanup() {
    // Remove inline icons (hover and permanent)
    document.querySelectorAll('.homesage-icon-wrapper, .homesage-permanent-icon').forEach(el => el.remove());

    // Remove sidebar
    if (sidebarElement) {
      sidebarElement.remove();
      sidebarElement = null;
    }

    // Clear scan/icon intervals
    if (scanIntervalId) { clearInterval(scanIntervalId); scanIntervalId = null; }
    if (zillowIconIntervalId) { clearInterval(zillowIconIntervalId); zillowIconIntervalId = null; }
    if (zillowScrollIntervalId) { clearInterval(zillowScrollIntervalId); zillowScrollIntervalId = null; }

    // Remove event listeners
    document.removeEventListener('mouseover', handleMouseOver);
    document.removeEventListener('mouseout', handleMouseOut);

    // Clean up tracked scroll listeners
    trackedScrollContainers.forEach(el => {
      if (onScrollHandler) el.removeEventListener('scroll', onScrollHandler);
    });
    trackedScrollContainers.length = 0;

    // Reset active icon state
    activeIcon = null;
    activeAddressElement = null;
  }

  // ==================== PERMANENT INLINE MODE ====================

  /**
   * Set up permanent mode — full re-render on initial load.
   * Removes all existing icons and re-inserts from scratch.
   */
  function setupPermanentMode() {
    const obs = domObserver;
    if (obs) obs.disconnect();

    document.querySelectorAll('.homesage-permanent-icon').forEach(el => el.remove());
    insertPermanentIcons();

    if (obs) {
      obs.observe(document.body, { childList: true, subtree: true });
    }
  }

  /**
   * Add icons only to address nodes that don't already have one.
   * Incremental — does NOT remove existing icons.
   */
  function addMissingPermanentIcons() {
    const obs = domObserver;
    if (obs) obs.disconnect();

    insertPermanentIcons();

    if (obs) obs.observe(document.body, { childList: true, subtree: true });
  }

  /**
   * Get the DOM insertion point for an icon so it appears in the same place
   * for both permanent and hover modes. Used by insertPermanentIcons and showInlineIcon.
   * Returns { parent, insertBefore } where insertBefore is the node to insert before, or null to append.
   * Delegates to the current site adapter; falls back to generic text-node insertion.
   */
  function getIconInsertionPoint(textNode, targetElement) {
    // Try site-specific adapter first
    if (textNode && currentAdapter?.getInsertionPoint) {
      const point = currentAdapter.getInsertionPoint(textNode);
      if (point) return point;
    }

    // Generic fallback: insert directly after the text node
    if (textNode && textNode.parentNode) {
      return { parent: textNode.parentNode, insertBefore: textNode.nextSibling };
    }

    return { parent: targetElement, insertBefore: null };
  }

  /**
   * Core icon insertion logic. Scans all address occurrences and inserts
   * icons where missing. Only skips when this exact DOM block already has
   * an icon (no address-text deduplication), so every listing shows an icon.
   */
  function insertPermanentIcons() {
    // Use the cached result from detectAddresses() to avoid a second full DOM traversal.
    // Fall back to a fresh scan only if cache is empty (e.g. called before detectAddresses ran).
    const allAddresses = detectedAddresses.length > 0
      ? detectedAddresses
      : (typeof AddressDetector !== 'undefined'
          ? AddressDetector.findAddressesInDOM(document.body, { deduplicate: false })
          : []);

    if (allAddresses.length === 0) return;

    const iconizedElements = new Set();

    // Pre-populate from existing icons: only track which DOM containers already have an icon.
    document.querySelectorAll('.homesage-permanent-icon').forEach(icon => {
      if (icon.isConnected && icon.parentElement) {
        iconizedElements.add(icon.parentElement);
      }
    });

    let newIcons = 0;

    allAddresses.forEach(addressData => {
      const textNode = addressData.node;
      const targetElement = addressData.parentElement;
      if (!targetElement || !targetElement.isConnected) return;

      // Apply site-specific filter (Redfin, Homes, Trulia require specific DOM contexts)
      if (currentAdapter?.shouldAddIcon && !currentAdapter.shouldAddIcon(targetElement)) return;

      // Skip if this element or nearby elements already have an icon
      if (targetElement.querySelector('.homesage-permanent-icon') ||
          targetElement.closest?.('.homesage-permanent-icon')) {
        return;
      }

      // Skip if any ancestor/descendant of this element was already iconized
      let alreadyIconized = false;
      for (const el of iconizedElements) {
        if (el.contains(targetElement) || targetElement.contains(el)) {
          alreadyIconized = true;
          break;
        }
      }
      if (alreadyIconized) return;

      // Check if the text node's immediate parent already has an icon sibling
      if (textNode && textNode.parentNode) {
        const siblings = textNode.parentNode.children;
        for (let i = 0; i < siblings.length; i++) {
          if (siblings[i].classList?.contains('homesage-permanent-icon')) return;
        }
      }

      // Create inline icon element
      const icon = document.createElement('span');
      icon.className = 'homesage-permanent-icon';
      icon.innerHTML = getIconInnerHTML();

      // Get full address and store on the element for the capture-phase handler
      const fullAddress = getFullAddress(addressData.address, targetElement);
      icon.dataset.address = fullAddress;

      try {
        const point = getIconInsertionPoint(textNode, targetElement);
        if (!point.parent || !point.parent.isConnected) {
          targetElement.appendChild(icon);
        } else if (point.insertBefore) {
          point.parent.insertBefore(icon, point.insertBefore);
        } else {
          point.parent.appendChild(icon);
        }
        // Homepage two-row cards: icon is appended inside div.address inline with the text.
        // Applying block display there causes the icon to sit below the text, extending
        // (or being clipped by) the card height — inconsistent across browsers.
        // Skip iconBlockMargin on the homepage so the icon stays inline.
        if (SITE.iconBlockMargin && !SITE.isHomesHomepage) {
          icon.style.display = 'block';
          icon.style.width = 'fit-content';
          icon.style.marginTop = SITE.iconBlockMargin;
        }

        iconizedElements.add(point.parent || targetElement);
        newIcons++;
      } catch (e) {
        try {
          targetElement.appendChild(icon);
          iconizedElements.add(targetElement);
          newIcons++;
        } catch (e2) {
          log('[HomeSage] Could not place permanent icon for:', addressData.address);
        }
      }
    });

    if (newIcons > 0) {
      log(`[HomeSage] Added ${newIcons} new icons`);
    }
  }

  // ==================== INLINE MODE (HOVER) ====================

  /**
   * Set up inline mode - icons appear on hover
   */
  function setupInlineMode() {
    document.addEventListener('mouseover', handleMouseOver);
    document.addEventListener('mouseout', handleMouseOut);
  }

  // Track the current address element the icon belongs to
  let activeAddressElement = null;
  let hideTimeout = null;

  /**
   * Handle mouse over events for inline mode
   */
  function handleMouseOver(event) {
    const target = event.target;
    
    // Check if hovering over the icon wrapper or overlay - keep it visible
    if (target.classList?.contains('homesage-icon-wrapper') ||
        target.closest?.('.homesage-icon-wrapper') ||
        target.classList?.contains('homesage-overlay-icon') ||
        target.closest?.('.homesage-overlay-icon')) {
      if (hideTimeout) {
        clearTimeout(hideTimeout);
        hideTimeout = null;
      }
      return;
    }

    // Check if hovering over an element containing a detected address
    const addressData = findAddressAtElement(target);
    
    if (addressData) {
      // Cancel any pending hide
      if (hideTimeout) {
        clearTimeout(hideTimeout);
        hideTimeout = null;
      }
      
      // Check if this is a different address occurrence than the current icon.
      // Compare by parentElement identity so same-address different-card also resets.
      if (activeIcon && activeAddressElement) {
        const isDifferentOccurrence = addressData.parentElement &&
          activeAddressElement !== addressData.parentElement &&
          !activeAddressElement.contains(addressData.parentElement) &&
          !addressData.parentElement.contains(activeAddressElement);
        if (isDifferentOccurrence) {
          activeIcon.remove();
          activeIcon = null;
          activeAddressElement = null;
        }
      }
      
      // Create icon if there isn't one
      if (!activeIcon) {
        if (hoverTimeout) clearTimeout(hoverTimeout);
        hoverTimeout = setTimeout(() => {
          showInlineIcon(addressData, target);
          // Track the stable address element (pre-scanned parent), not the
          // arbitrary hovered element, so mouseout containment checks work correctly.
          activeAddressElement = addressData.parentElement || target;
        }, HOVER_DELAY);
      }
    }
  }

  /**
   * Handle mouse out events
   */
  function handleMouseOut(event) {
    if (hoverTimeout) {
      clearTimeout(hoverTimeout);
      hoverTimeout = null;
    }

    const relatedTarget = event.relatedTarget;

    // Don't hide if moving to the icon itself
    if (relatedTarget && (
      relatedTarget.classList?.contains('homesage-icon-wrapper') ||
      relatedTarget.closest?.('.homesage-icon-wrapper')
    )) {
      return;
    }

    // Don't hide if still within the address element or its container
    if (relatedTarget && activeAddressElement) {
      // Direct containment check
      if (relatedTarget === activeAddressElement ||
          activeAddressElement.contains(relatedTarget) ||
          relatedTarget.contains(activeAddressElement)) {
        return;
      }
      // Check if both elements share a common small container (same card)
      // Walk up from activeAddressElement to find a reasonable container
      let container = activeAddressElement;
      for (let i = 0; i < 5 && container && container !== document.body; i++) {
        if (container.contains(relatedTarget)) {
          return;
        }
        container = container.parentElement;
      }
    }

    // Don't hide if moving to another element that contains the same address occurrence.
    // Keep activeAddressElement pointing to the stable pre-scanned parent — do NOT
    // reassign to the raw relatedTarget, which could be any arbitrary hovered element.
    if (relatedTarget) {
      const newAddressData = findAddressAtElement(relatedTarget);
      if (newAddressData && activeAddressElement) {
        const currentAddressData = findAddressAtElement(activeAddressElement);
        if (currentAddressData && newAddressData.parentElement === currentAddressData.parentElement) {
          return;
        }
      }
    }

    // Remove icon after a delay — gives the mouse time to reach the icon
    // when it's placed outside the <a> tag (Redfin). The handleMouseOver
    // function clears this timeout if the mouse reaches the wrapper.
    if (activeIcon) {
      // Clear any existing timeout first — prevents orphaned timers from
      // earlier mouseout events that would fire before this new 400ms window.
      if (hideTimeout) {
        clearTimeout(hideTimeout);
      }
      hideTimeout = setTimeout(() => {
        if (activeIcon) {
          activeIcon.remove();
          activeIcon = null;
          activeAddressElement = null;
          removeOverlay();
        }
      }, 400);
    }
  }

  /**
   * Show inline icon next to an address.
   * Inserts the icon in the DOM at the same place as the permanent icon would be
   * (Redfin: after <a>, Zillow: after <address> then outside overflow, default: after text).
   * The icon scrolls with the page and does not move when the user scrolls.
   */
  function showInlineIcon(addressData, targetElement) {
    if (activeIcon) {
      activeIcon.remove();
      activeIcon = null;
    }
    removeOverlay();

    // Always use the pre-scanned address element as the reference — not the arbitrary
    // hovered element — so site adapters get the correct text node and DOM context.
    const refElement = addressData.parentElement || targetElement;

    // Apply the same site-specific filter as permanent mode so we never place a
    // hover icon in a context the adapter considers invalid (e.g. Zillow stats spans).
    if (currentAdapter?.shouldAddIcon && !currentAdapter.shouldAddIcon(refElement)) return;

    const fullAddress = getFullAddress(addressData.address, refElement);
    const textNode = addressData.node || findTextNodeWithAddress(refElement, addressData.address);

    const point = getIconInsertionPoint(textNode, refElement);
    if (!point.parent || !point.parent.isConnected) {
      return;
    }

    const icon = document.createElement('span');
    icon.className = 'homesage-permanent-icon homesage-icon-wrapper homesage-inline-hover-icon';
    icon.innerHTML = getIconInnerHTML();
    icon.dataset.address = fullAddress;

    if (SITE.iconBlockMargin && !SITE.isHomesHomepage) {
      icon.style.display = 'block';
      icon.style.width = 'fit-content';
      icon.style.marginTop = SITE.iconBlockMargin;
    }

    if (point.insertBefore) {
      point.parent.insertBefore(icon, point.insertBefore);
    } else {
      point.parent.appendChild(icon);
    }

    icon.addEventListener('mouseleave', (e) => {
      const relatedTarget = e.relatedTarget;
      if (relatedTarget && activeAddressElement && (
        relatedTarget === activeAddressElement || activeAddressElement.contains(relatedTarget)
      )) return;
      if (relatedTarget && activeAddressElement) {
        let container = activeAddressElement;
        for (let i = 0; i < 5 && container && container !== document.body; i++) {
          if (container.contains(relatedTarget)) return;
          container = container.parentElement;
        }
      }
      if (hideTimeout) clearTimeout(hideTimeout);
      hideTimeout = setTimeout(() => {
        if (activeIcon) {
          activeIcon.remove();
          activeIcon = null;
          activeAddressElement = null;
          activeOverlay = null;
        }
      }, 400);
    });

    activeIcon = icon;
    activeOverlay = null;
  }

  /**
   * Try to get the full address including city/state/zip.
   * If the detected address is just a street (e.g., "640 3rd St"),
   * check the parent element's textContent for a fuller version.
   */
  function getFullAddress(partialAddress, element) {
    // Strip pipe-separated property name prefix
    // e.g. "Building Name | 620 W Surf St, Chicago, IL" → "620 W Surf St, Chicago, IL"
    // Uses regex to handle both ASCII spaces and &nbsp; (\u00a0) around the pipe
    let addr = partialAddress;
    const pipeMatch = addr.match(/^.+?\s*\|\s*(.+)/);
    if (pipeMatch) {
      const afterPipe = pipeMatch[1].trim();
      if (afterPipe.length > 5) addr = afterPipe;
    }

    // If it ends with a US state abbreviation (optionally followed by ZIP), it's complete
    if (/\b(?:AL|AK|AZ|AR|CA|CO|CT|DE|FL|GA|HI|ID|IL|IN|IA|KS|KY|LA|ME|MD|MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ|NM|NY|NC|ND|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VT|VA|WA|WV|WI|WY|DC)\b(\s+\d{4,5}(-\d{4})?)?\s*$/.test(addr)) {
      return addr;
    }

    // Normalize helper: collapse whitespace for fuzzy matching
    const normalize = s => s.replace(/\s+/g, ' ').trim().toLowerCase();
    const prefix = normalize(addr).substring(0, 15);

    // Walk up a few levels and look for a longer address in the combined text
    let el = element;
    for (let i = 0; i < 5 && el && el !== document.body; i++) {
      const text = AddressDetector._getTextWithSpaces(el);
      if (text && text.length < 500) {
        // Try to find a full address in the parent's text
        const addresses = AddressDetector.findAddresses(text);
        for (const candidate of addresses) {
          if (AddressDetector.isValidAddress(candidate.text) &&
              normalize(candidate.text).includes(prefix) &&
              candidate.text.length > addr.length) {
            // Redfin: candidate text from the parent element may include a pipe-separated
            // display name prefix (e.g. "536 W. Grant Pl. | 536 W Grant Pl, Chicago, IL").
            // Strip it the same way we strip the initial partialAddress.
            if (SITE.isRedfin) {
              const pm = candidate.text.match(/^.+?\s*\|\s*(.+)/);
              if (pm && pm[1].trim().length > 5) return pm[1].trim();
            }
            return candidate.text;
          }
        }
      }
      el = el.parentElement;
    }

    return addr;
  }

  /**
   * Capture-phase click handler for HomeSage icons.
   * Intercepts clicks BEFORE they reach any parent element (like <a> tags),
   * preventing navigation and ensuring our popup opens.
   */
  function handleHomesageIconClick(e) {
    // Check if the click target is inside a HomeSage icon or overlay
    const permanentIcon = e.target.closest?.('.homesage-permanent-icon');
    const hoverIcon = e.target.closest?.('.homesage-icon-wrapper');
    const overlayIcon = e.target.closest?.('.homesage-overlay-icon');
    const icon = overlayIcon || permanentIcon || hoverIcon;

    if (!icon) return;

    // Stop the event from reaching ANY other handler
    e.stopPropagation();
    e.stopImmediatePropagation();
    e.preventDefault();

    // Determine which part was clicked
    const isSettings = e.target.closest?.('.homesage-permanent-settings, .homesage-change-link');
    
    if (isSettings) {
      try { chrome.runtime.sendMessage({ action: 'openSettings' }).catch(() => {}); } catch(err) {}
      removeOverlay();
      return;
    }

    // Logo clicked — open popup with the address stored on the icon
    const address = icon.dataset.address;
    if (address) {
      // Use the original icon (not overlay) for positioning if available
      const positionAnchor = (overlayIcon && overlayIcon._sourceIcon) || icon;
      removeOverlay();
      openPopup(address, positionAnchor);
    }
  }

  // ==================== FLOATING OVERLAY ON HOVER ====================
  // When the user hovers over a HomeSage icon, we ALWAYS create a fixed-position
  // clone appended to document.body. This guarantees the clickable element is
  // outside any parent <a>, button, or clickable card container — regardless of
  // where the original icon was inserted in the DOM.
  // The overlay receives all clicks, so the site's navigation never fires.

  let activeOverlay = null;

  function createOverlayForIcon(icon) {
    if (!icon || !icon.isConnected) return;
    // Don't create an overlay for the popup's hidden anchor icon.
    // visibility:hidden keeps the element in layout and mouse-reachable, so mouseover
    // can still fire on it. If we created an overlay, removeOverlay() would later
    // restore visibility while the popup is still open — causing the icon to flicker back.
    if (icon.style.visibility === 'hidden') return;
    if (activeOverlay && activeOverlay._sourceIcon === icon) return;

    removeOverlay();

    const rect = icon.getBoundingClientRect();
    const overlay = document.createElement('span');
    overlay.className = 'homesage-overlay-icon';
    overlay.innerHTML = icon.innerHTML;
    overlay.dataset.address = icon.dataset.address || '';
    overlay.style.cssText = `
      position: fixed !important;
      left: ${rect.left}px !important;
      top: ${rect.top}px !important;
      z-index: 10000000 !important;
      display: inline-flex !important;
      align-items: center !important;
      gap: 3px !important;
      cursor: pointer !important;
      background: inherit !important;
      pointer-events: auto !important;
    `;
    overlay._sourceIcon = icon;
    icon.style.visibility = 'hidden';

    overlay.addEventListener('mouseleave', () => removeOverlay());

    document.body.appendChild(overlay);
    activeOverlay = overlay;
  }

  document.addEventListener('mouseover', (e) => {
    if (e.target.closest?.('.homesage-overlay-icon')) return;
    const icon = e.target.closest?.('.homesage-permanent-icon, .homesage-icon-wrapper');
    if (icon) createOverlayForIcon(icon);
  }, true);

  // Redfin / homes.com / realtor.com: mouseover may not reach our icon when hovering (card/link overlay on top).
  // Use mousemove + hit-test so we create the overlay when the cursor is inside our icon.
  if (SITE.needsMousemoveOverlay) {
    let lastIconCheck = 0;
    document.addEventListener('mousemove', (e) => {
      if (Date.now() - lastIconCheck < 50) return;
      lastIconCheck = Date.now();

      if (e.target.closest?.('.homesage-overlay-icon')) return;

      // If an overlay exists, check whether the cursor is still over it.
      // mouseleave can be missed on fast cursor moves, so we use the
      // mousemove hit-test as a reliable fallback removal mechanism.
      if (activeOverlay) {
        const rect = activeOverlay.getBoundingClientRect();
        const stillOver = e.clientX >= rect.left && e.clientX <= rect.right &&
                          e.clientY >= rect.top  && e.clientY <= rect.bottom;
        if (!stillOver) removeOverlay();
        return;
      }

      const icons = document.querySelectorAll('.homesage-permanent-icon, .homesage-icon-wrapper');
      for (const icon of icons) {
        const rect = icon.getBoundingClientRect();
        if (e.clientX >= rect.left && e.clientX <= rect.right &&
            e.clientY >= rect.top && e.clientY <= rect.bottom) {
          createOverlayForIcon(icon);
          break;
        }
      }
    }, { passive: true });
  }

  // Also remove overlay when mouse leaves the original icon area
  document.addEventListener('mouseout', (e) => {
    if (!activeOverlay) return;
    const icon = e.target.closest?.('.homesage-permanent-icon, .homesage-icon-wrapper');
    if (!icon) return;
    // Small delay to allow mouse to reach the overlay
    setTimeout(() => {
      if (activeOverlay && !activeOverlay.matches(':hover')) {
        removeOverlay();
      }
    }, 100);
  }, true);

  function removeOverlay() {
    if (activeOverlay) {
      // Restore original icon visibility
      if (activeOverlay._sourceIcon) {
        activeOverlay._sourceIcon.style.visibility = '';
      }
      activeOverlay.remove();
      activeOverlay = null;
    }
  }

  /**
   * Find the text node inside an element that contains the address text
   */
  function findTextNodeWithAddress(element, address) {
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, null);
    const normalizedAddress = address.toLowerCase().replace(/\s+/g, ' ').trim();
    
    let node;
    while ((node = walker.nextNode())) {
      const text = node.textContent.toLowerCase().replace(/\s+/g, ' ').trim();
      if (text && normalizedAddress.includes(text.substring(0, 20))) {
        return node;
      }
    }
    return null;
  }

  // ==================== SIDEBAR MODE ====================

  /**
   * Set up sidebar mode
   */
  function setupSidebarMode() {
    if (detectedAddresses.length === 0) return;

    sidebarElement = document.createElement('div');
    sidebarElement.className = 'homesage-sidebar';
    sidebarElement.innerHTML = `
      <div class="homesage-sidebar-header">
        <img src="${ICON_URL}" alt="HomeSage" />
        <span>${detectedAddresses.length} address${detectedAddresses.length !== 1 ? 'es' : ''}</span>
      </div>
    `;

    sidebarElement.addEventListener('click', (e) => {
      e.stopPropagation();
      openAddressList(sidebarElement);
    });

    document.body.appendChild(sidebarElement);
  }

  /**
   * Open address list panel
   */
  function openAddressList(anchorElement) {
    // Close existing popup
    closePopup();

    // Get position from anchor element
    const rect = anchorElement.getBoundingClientRect();
    const top = rect.top + window.scrollY;
    const left = rect.left + window.scrollX - 340;

    // Create address list panel
    activePopup = document.createElement('div');
    activePopup.className = 'homesage-popup homesage-address-list';
    
    // Build address list HTML
    const addressListHTML = detectedAddresses.map((data, index) => `
      <div class="homesage-address-item" data-index="${index}">
        <span class="homesage-address-text">${escapeHtml(data.address)}</span>
        <svg class="homesage-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="9 18 15 12 9 6"></polyline>
        </svg>
      </div>
    `).join('');

    activePopup.innerHTML = `
      <div class="homesage-popup-header">
        <img src="${ICON_URL}" alt="HomeSage" class="homesage-popup-logo" />
        <span>Addresses Found (${detectedAddresses.length})</span>
        <button class="homesage-settings-btn" title="Settings">
          ${getSettingsSVG()}
        </button>
      </div>
      <div class="homesage-address-list-content">
        ${addressListHTML}
      </div>
    `;

    // Position popup
    activePopup.style.position = 'absolute';
    activePopup.style.top = `${top}px`;
    activePopup.style.left = `${left}px`;
    activePopup.style.zIndex = '9999999';

    document.body.appendChild(activePopup);
    adjustPopupPosition(activePopup);

    // Set up event listeners
    activePopup.querySelector('.homesage-settings-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      try { chrome.runtime.sendMessage({ action: 'openSettings' }).catch(() => {}); } catch(e) {}
    });

    // Address item click handlers
    activePopup.querySelectorAll('.homesage-address-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        
        const index = parseInt(item.dataset.index, 10);
        const address = detectedAddresses[index]?.address;
        
        if (address) {
          // Remove click outside listener before opening new popup
          document.removeEventListener('click', handleClickOutside);
          clickOutsideRegistered = false;

          // Small delay to ensure clean transition
          setTimeout(() => {
            openPopup(address, anchorElement);
          }, 10);
        }
      });
    });

    // Close on click outside
    if (!clickOutsideRegistered) {
      document.addEventListener('click', handleClickOutside);
      clickOutsideRegistered = true;
    }
  }

  /**
   * Update sidebar content
   */
  function updateSidebar() {
    if (sidebarElement) {
      const count = detectedAddresses.length;
      sidebarElement.querySelector('span').textContent = 
        `${count} address${count !== 1 ? 'es' : ''}`;
      
      if (count === 0) {
        sidebarElement.style.display = 'none';
      } else {
        sidebarElement.style.display = 'flex';
      }
    }
  }

  // ==================== RIGHT-CLICK MODE ====================

  /**
   * Set up right-click context menu mode
   */
  function setupRightClickMode() {
    // Context menu is handled by background script
    // We just need to track selected text
    document.addEventListener('mouseup', () => {
      const selection = window.getSelection().toString().trim();
      if (selection && AddressDetector.isValidAddress(selection)) {
        try { chrome.runtime.sendMessage({
          action: 'setSelectedAddress',
          address: selection
        }).catch(() => {}); } catch(e) {}
      }
    });
  }

  // ==================== HELPERS ====================

  /**
   * Find if an element contains a detected address.
   * Returns the address data for the occurrence that the element belongs to (critical for
   * repeated addresses: we must match the hovered card's occurrence, not the first in the list).
   * Matches when:
   * - element is the address parent, or
   * - element contains the address parent (e.g. card contains address), or
   * - the address parent contains element (e.g. user hovered a child inside the address block).
   */
  function findAddressAtElement(element) {
    // Prefer DOM containment so we get the correct occurrence when the same address appears multiple times
    for (const data of detectedAddresses) {
      const parent = data.parentElement;
      if (!parent || !parent.isConnected) continue;
      if (element === parent || element.contains(parent) || parent.contains(element)) {
        return data;
      }
    }

    // Fallback: match by text (may return wrong occurrence if address repeats; used when DOM structure doesn't match)
    const text = element.textContent || '';
    for (const data of detectedAddresses) {
      if (text.includes(data.address)) {
        // Prefer the occurrence that is under this element so icon is placed correctly
        if (data.parentElement && (data.parentElement.contains(element) || element.contains(data.parentElement))) {
          return data;
        }
      }
    }
    for (const data of detectedAddresses) {
      if (text.includes(data.address)) return data;
    }
    return null;
  }

  // ==================== INLINE POPUP ====================

  /**
   * Open inline popup with address data
   * @param {string} address - The property address
   * @param {Element|Object} anchorOrPosition - Element to position near, or {top, left} coordinates
   */
  function openPopup(address, anchorOrPosition = null) {
    // Capture position BEFORE closePopup removes the icon
    let anchorRect = null;
    let isPosition = false;
    let isSidebar = false;
    
    if (anchorOrPosition) {
      if (typeof anchorOrPosition.top === 'number' && typeof anchorOrPosition.left === 'number') {
        isPosition = true;
      } else if (anchorOrPosition instanceof Element) {
        anchorRect = anchorOrPosition.getBoundingClientRect();
        isSidebar = anchorOrPosition.classList.contains('homesage-sidebar');
      }
    }

    // Close existing popup (this also removes the icon and restores any hidden anchor)
    closePopup();

    // Hide the permanent icon that triggered this popup so it doesn't show
    // alongside the popup. It will be restored when the popup closes.
    if (anchorOrPosition instanceof Element &&
        anchorOrPosition.classList.contains('homesage-permanent-icon') &&
        anchorOrPosition.isConnected) {
      popupAnchorIcon = anchorOrPosition;
      popupAnchorIcon.style.visibility = 'hidden';
    }

    // Get position from captured rect, position object, or use default
    let top = window.scrollY + 100;
    let left = window.scrollX + 100;
    
    if (anchorOrPosition) {
      if (isPosition) {
        top = anchorOrPosition.top;
        left = anchorOrPosition.left;
      } else if (anchorRect) {
        const rect = anchorRect;
        
        // Check if anchor is the sidebar (positioned on right side)
        if (isSidebar) {
          // Position to the left of the sidebar
          top = rect.top + window.scrollY;
          left = rect.left + window.scrollX - 340; // popup width + gap
        } else {
          // Position below the anchor
          top = rect.bottom + window.scrollY + 8;
          left = rect.left + window.scrollX;
        }
      }
    } else if (activeIcon) {
      // Fall back to active icon
      const rect = activeIcon.getBoundingClientRect();
      top = rect.bottom + window.scrollY + 8;
      left = rect.left + window.scrollX;
    }

    // Create popup element
    activePopup = document.createElement('div');
    activePopup.className = 'homesage-popup';
    activePopup.innerHTML = `
      <div class="homesage-popup-header">
        <img src="${ICON_URL}" alt="HomeSage" class="homesage-popup-logo" />
        <span>HomeSage.ai</span>
        <div class="homesage-header-actions">
          <button class="homesage-favorite-btn" title="Save to favorites">
            <svg class="homesage-heart-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
            </svg>
          </button>
          <button class="homesage-settings-btn" title="Settings">
            ${getSettingsSVG()}
          </button>
        </div>
      </div>
      <div class="homesage-popup-content">
        <div class="homesage-popup-address">${escapeHtml(address)}</div>
        <div class="homesage-subscription-status" style="display: none;"></div>
        <div class="homesage-popup-loading">
          <div class="homesage-spinner"></div>
          <span>Loading...</span>
        </div>
        <div class="homesage-popup-details" style="display: none;">
          <div class="homesage-detail">
            <span class="homesage-label">Sq Ft</span>
            <span class="homesage-value" id="homesage-sqft">--</span>
          </div>
          <div class="homesage-detail">
            <span class="homesage-label">Beds</span>
            <span class="homesage-value" id="homesage-beds">--</span>
          </div>
          <div class="homesage-detail">
            <span class="homesage-label">Baths</span>
            <span class="homesage-value" id="homesage-baths">--</span>
          </div>
        </div>
        <button class="homesage-popup-btn homesage-btn-primary" id="homesage-run-report">
          Run Full Property Report
        </button>
        <div class="homesage-popup-divider"><span>or</span></div>
        <button class="homesage-popup-btn homesage-btn-secondary" id="homesage-manual-entry">
          Enter Different Address
        </button>
      </div>
      <div class="homesage-popup-manual" style="display: none;">
        ${getManualEntryHTML()}
      </div>
    `;

    // Position popup
    activePopup.style.position = 'absolute';
    activePopup.style.top = `${top}px`;
    activePopup.style.left = `${left}px`;
    activePopup.style.zIndex = '9999999';

    // Ensure popup stays within viewport
    document.body.appendChild(activePopup);
    adjustPopupPosition(activePopup);

    // Set up event listeners
    setupPopupEventListeners(activePopup, address);

    // Check authentication first
    checkAuthAndLoadData(address);
  }

  /**
   * Check authentication and load data accordingly
   */
  async function checkAuthAndLoadData(address) {
    if (!activePopup) return;

    try {
      // Check if user is authenticated
      const authResult = await safeSendMessage({ action: 'checkAuth' });
      if (!authResult) {
        showLoginRequiredState();
        return;
      }
      
      log('[HomeSage] Auth check result:', authResult);
      
      if (!activePopup) return;

      if (authResult && authResult.authenticated) {
        // User is logged in - check subscription status
        log('[HomeSage] User is authenticated, checking subscription...');
        
        const subResult = await safeSendMessage({ action: 'checkSubscription' });
        if (!subResult) return; // Extension context lost
        log('[HomeSage] Subscription result:', subResult);
        
        if (!activePopup) return;
        
        // Show subscription status
        showSubscriptionStatus(subResult);
        
        // Sync favorites with server in background (don't block UI)
        safeSendMessage({ action: 'syncFavorites' }).catch(() => {});
        
        // Fetch and show actual property data from API
        fetchAndShowPropertyData(address);
      } else {
        // User is not logged in - show login prompt
        log('[HomeSage] User is NOT authenticated');
        showLoginRequiredState();
      }
    } catch (error) {
      console.error('[HomeSage] Auth check error:', error);
      // On error, assume not logged in and show login prompt
      showLoginRequiredState();
    }
  }

  /**
   * Show subscription status in popup
   */
  function showSubscriptionStatus(subResult) {
    if (!activePopup) return;
    
    const statusEl = activePopup.querySelector('.homesage-subscription-status');
    if (!statusEl) return;
    
    if (subResult.hasSubscription) {
      // Paid user - show credits
      statusEl.innerHTML = `
        <div class="homesage-status-badge homesage-status-pro">
          <span class="homesage-status-label">Pro</span>
          <span class="homesage-status-credits">${Number(subResult.remainingCredits).toLocaleString()} credits</span>
        </div>
      `;
    } else if (subResult.isFreeUser) {
      // Free user - show free reports remaining
      statusEl.innerHTML = `
        <div class="homesage-status-badge homesage-status-free">
          <span class="homesage-status-label">Free</span>
          <span class="homesage-status-credits">${subResult.freeReportsRemaining}/3 reports left</span>
        </div>
      `;
    } else {
      // Error or unknown state
      statusEl.innerHTML = `
        <div class="homesage-status-badge homesage-status-unknown">
          <span class="homesage-status-label">Status unknown</span>
        </div>
      `;
    }
    
    statusEl.style.display = 'block';
  }

  /**
   * Fetch and show property data from API
   */
  async function fetchAndShowPropertyData(address) {
    if (!activePopup) return;
    
    const loading = activePopup.querySelector('.homesage-popup-loading');
    const details = activePopup.querySelector('.homesage-popup-details');
    
    try {
      // Fetch property data from background script
      const result = await safeSendMessage({ 
        action: 'getPropertyData', 
        address: address 
      });
      
      if (!activePopup) return;
      
      if (loading) loading.style.display = 'none';
      
      if (result.success && result.data) {
        const data = result.data;
        
        // Check if address was found in database
        if (!data.found) {
          showAddressNotFound();
          return;
        }
        
        if (details) {
          details.style.display = 'flex';
          const sqftNum = Number(data.sqft);
          activePopup.querySelector('#homesage-sqft').textContent = (data.sqft && !isNaN(sqftNum)) ? sqftNum.toLocaleString() : '--';
          activePopup.querySelector('#homesage-beds').textContent = data.beds || '--';
          activePopup.querySelector('#homesage-baths').textContent = data.baths || '--';
        }
      } else {
        // API failed - show address not found
        showAddressNotFound();
      }
    } catch (error) {
      console.error('[HomeSage] Error fetching property data:', error);
      if (loading) loading.style.display = 'none';
      showAddressNotFound();
    }
  }

  /**
   * Generate the "address not found" warning HTML block.
   */
  function getAddressNotFoundHTML(buttonId, buttonLabel) {
    return `
      <div style="text-align: center; padding: 20px;">
        <svg width="48" height="48" viewBox="0 0 48 48" fill="none" style="display: block; margin: 0 auto 12px;">
          <circle cx="24" cy="24" r="20" stroke="#E8A317" stroke-width="2.5" fill="none"/>
          <line x1="24" y1="14" x2="24" y2="28" stroke="#E8A317" stroke-width="2.5" stroke-linecap="round"/>
          <circle cx="24" cy="34" r="1.5" fill="#E8A317"/>
        </svg>
        <p style="color: #333; font-weight: 600; font-size: 15px; margin: 0 0 6px;">Address not found</p>
        <p style="color: #666; font-size: 13px; margin: 0 0 16px;">This address is not in our database.</p>
        <button class="homesage-popup-btn homesage-btn-primary" id="${buttonId}">
          ${escapeHtml(buttonLabel)}
        </button>
      </div>
    `;
  }

  /**
   * Show address not found message in inline popup
   */
  function showAddressNotFound() {
    if (!activePopup) return;

    const content = activePopup.querySelector('.homesage-popup-content');
    if (!content) return;

    // Hide favorite button - not applicable for unfound addresses
    const favoriteBtn = activePopup.querySelector('.homesage-favorite-btn');
    if (favoriteBtn) favoriteBtn.style.display = 'none';

    // Replace content with address not found message
    content.innerHTML = getAddressNotFoundHTML('homesage-notfound-manual', 'Enter Different Address');
    
    // Add listener for manual entry button
    const manualBtn = content.querySelector('#homesage-notfound-manual');
    if (manualBtn) {
      manualBtn.addEventListener('click', () => {
        content.style.display = 'none';
        const manual = activePopup.querySelector('.homesage-popup-manual');
        if (manual) manual.style.display = 'block';
      });
    }
  }
  
  /**
   * Show login required state
   */
  function showLoginRequiredState() {
    if (!activePopup) return;
    
    const content = activePopup.querySelector('.homesage-popup-content');
    const manual = activePopup.querySelector('.homesage-popup-manual');
    let loginState = activePopup.querySelector('.homesage-login-state');
    
    // Hide heart icon - not applicable when not logged in
    const favoriteBtn = activePopup.querySelector('.homesage-favorite-btn');
    if (favoriteBtn) favoriteBtn.style.display = 'none';
    
    // Hide other states
    if (content) content.style.display = 'none';
    if (manual) manual.style.display = 'none';
    
    // Create login state if it doesn't exist
    if (!loginState) {
      loginState = document.createElement('div');
      loginState.className = 'homesage-login-state';
      loginState.innerHTML = `
        <div class="homesage-login-message">
          <svg class="homesage-icon-lock" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
          </svg>
          <h3>Please log in to continue</h3>
          <p>Sign in to your HomeSage.ai account to view property details and generate reports.</p>
        </div>
        <button class="homesage-popup-btn homesage-btn-primary" id="homesage-login-btn">
          Log In
        </button>
        <p class="homesage-signup-link">
          Don't have an account? <a href="#" id="homesage-signup-link">Sign up</a>
        </p>
      `;
      
      // Insert before footer
      const footer = activePopup.querySelector('.homesage-popup-footer');
      activePopup.insertBefore(loginState, footer);
      
      // Add event listeners
      loginState.querySelector('#homesage-login-btn').addEventListener('click', () => {
        window.open(`${HOMESAGE_API_BASE_URL}/login`, '_blank');
        closePopup();
      });

      loginState.querySelector('#homesage-signup-link').addEventListener('click', (e) => {
        e.preventDefault();
        window.open(`${HOMESAGE_API_BASE_URL}/signup`, '_blank');
        closePopup();
      });
    }
    
    loginState.style.display = 'block';
  }

  /**
   * Close the inline popup
   */
  function closePopup() {
    if (activePopup) {
      activePopup.remove();
      activePopup = null;
    }
    // Also remove the inline icon
    if (activeIcon) {
      activeIcon.remove();
      activeIcon = null;
      activeAddressElement = null;
    }
    // Restore the permanent icon that was hidden when the popup opened
    if (popupAnchorIcon) {
      popupAnchorIcon.style.visibility = '';
      popupAnchorIcon = null;
    }
    document.removeEventListener('click', handleClickOutside);
    clickOutsideRegistered = false;
  }

  /**
   * Adjust popup position to stay within viewport
   * Runs immediately and again after a short delay to catch dynamic content
   */
  function adjustPopupPosition(popup) {
    doAdjust(popup);
    // Re-adjust after content loads (auth, property data, subscription status)
    requestAnimationFrame(() => doAdjust(popup));
    setTimeout(() => doAdjust(popup), 300);
    setTimeout(() => doAdjust(popup), 800);
  }

  function doAdjust(popup) {
    if (!popup || !popup.isConnected) return;
    
    const rect = popup.getBoundingClientRect();
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    const margin = 10;

    // Adjust horizontal: keep within left and right edges
    if (rect.right > viewportWidth - margin) {
      popup.style.left = `${viewportWidth - rect.width - margin + window.scrollX}px`;
    }
    if (rect.left < margin) {
      popup.style.left = `${margin + window.scrollX}px`;
    }

    // Adjust vertical: keep within top and bottom edges
    if (rect.bottom > viewportHeight - margin) {
      popup.style.top = `${window.scrollY + viewportHeight - rect.height - margin}px`;
    }
    if (rect.top < margin) {
      popup.style.top = `${window.scrollY + margin}px`;
    }

    // If popup is taller than viewport, pin to top and allow scrolling
    if (rect.height > viewportHeight - margin * 2) {
      popup.style.top = `${window.scrollY + margin}px`;
      popup.style.maxHeight = `${viewportHeight - margin * 2}px`;
      popup.style.overflowY = 'auto';
    }
  }

  /**
   * Set up popup event listeners
   */
  function setupPopupEventListeners(popup, address) {
    // Favorite button (toggle and save)
    const favoriteBtn = popup.querySelector('.homesage-favorite-btn');
    if (favoriteBtn) {
      // Check if already favorited
      checkIfFavorited(address).then(isFavorited => {
        if (isFavorited) {
          favoriteBtn.classList.add('favorited');
        }
      });

      favoriteBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const isNowFavorited = !favoriteBtn.classList.contains('favorited');
        favoriteBtn.classList.toggle('favorited');
        
        if (isNowFavorited) {
          addToFavorites(address);
        } else {
          removeFromFavorites(address);
        }
      });
    }

    // Settings button
    const settingsBtn = popup.querySelector('.homesage-settings-btn');
    if (settingsBtn) {
      settingsBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        try { chrome.runtime.sendMessage({ action: 'openSettings' }).catch(() => {}); } catch(e) {}
      });
    }

    // Run report button
    popup.querySelector('#homesage-run-report').addEventListener('click', () => {
      runReport(address);
    });

    // Manual entry button
    popup.querySelector('#homesage-manual-entry').addEventListener('click', () => {
      popup.querySelector('.homesage-popup-content').style.display = 'none';
      popup.querySelector('.homesage-popup-manual').style.display = 'block';
      popup.querySelector('#homesage-address-input').focus();
    });

    // Back button
    popup.querySelector('#homesage-back-btn').addEventListener('click', () => {
      popup.querySelector('.homesage-popup-manual').style.display = 'none';
      popup.querySelector('.homesage-popup-content').style.display = 'block';
    });

    // Search button
    popup.querySelector('#homesage-search-btn').addEventListener('click', async () => {
      const input = popup.querySelector('#homesage-address-input');
      const newAddress = input.value.trim();
      if (newAddress) {
        // First check if property exists in database
        const result = await safeSendMessage({ 
          action: 'getPropertyData', 
          address: newAddress 
        });
        
        if (!result.success || !result.data || !result.data.found) {
          // Show address not found in the manual entry area
          const manual = popup.querySelector('.homesage-popup-manual');
          if (manual) {
            manual.innerHTML = getAddressNotFoundHTML('homesage-try-again-btn', 'Try Another Address');
            manual.querySelector('#homesage-try-again-btn').addEventListener('click', (e) => {
              e.stopPropagation();
              e.preventDefault();
              manual.innerHTML = getManualEntryHTML();
              // Re-attach listeners for the new elements
              setupManualEntryListeners(popup, address);
            });
          }
          return;
        }
        
        // Address found - proceed with report
        runReport(newAddress);
      }
    });

    // Enter key in input
    popup.querySelector('#homesage-address-input').addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        hideInlineAutocomplete(popup);
        popup.querySelector('#homesage-search-btn')?.click();
      }
    });

    // Autocomplete on input
    setupInlineAutocomplete(popup);

    // Close on click outside
    if (!clickOutsideRegistered) {
      document.addEventListener('click', handleClickOutside);
      clickOutsideRegistered = true;
    }
  }

  /**
   * Re-attach manual entry listeners after "Try Another Address"
   */
  function setupManualEntryListeners(popup, originalAddress) {
    const searchBtn = popup.querySelector('#homesage-search-btn');
    const backBtn = popup.querySelector('#homesage-back-btn');
    const input = popup.querySelector('#homesage-address-input');

    if (searchBtn) {
      searchBtn.addEventListener('click', async () => {
        const newAddress = input?.value.trim();
        if (newAddress) {
          const result = await safeSendMessage({ 
            action: 'getPropertyData', 
            address: newAddress 
          });
          
          if (!result.success || !result.data || !result.data.found) {
            const manual = popup.querySelector('.homesage-popup-manual');
            if (manual) {
              manual.innerHTML = getAddressNotFoundHTML('homesage-try-again-btn', 'Try Another Address');
              manual.querySelector('#homesage-try-again-btn').addEventListener('click', (e) => {
                e.stopPropagation();
                e.preventDefault();
                manual.innerHTML = getManualEntryHTML();
                setupManualEntryListeners(popup, originalAddress);
              });
            }
            return;
          }
          
          runReport(newAddress);
        }
      });
    }

    if (backBtn) {
      backBtn.addEventListener('click', () => {
        popup.querySelector('.homesage-popup-manual').style.display = 'none';
        popup.querySelector('.homesage-popup-content').style.display = 'block';
      });
    }

    if (input) {
      input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          hideInlineAutocomplete(popup);
          searchBtn?.click();
        }
      });
      input.focus();
    }

    // Set up autocomplete
    setupInlineAutocomplete(popup);
  }

  // ==================== INLINE AUTOCOMPLETE ====================

  /**
   * Set up autocomplete for an inline popup's address input
   */
  function setupInlineAutocomplete(popup) {
    const input = popup.querySelector('#homesage-address-input');
    const dropdown = popup.querySelector('.homesage-autocomplete-dropdown');
    if (!input || !dropdown) return;

    let acDebounce = null;

    input.addEventListener('input', () => {
      const value = input.value.trim();
      if (acDebounce) clearTimeout(acDebounce);
      if (value.length < 3) {
        dropdown.style.display = 'none';
        dropdown.innerHTML = '';
        return;
      }
      acDebounce = setTimeout(async () => {
        try {
          const response = await safeSendMessage({ action: 'autoComplete', input: value });
          if (response?.success && response.results?.length > 0) {
            showInlineAutocompleteResults(dropdown, input, response.results);
          } else {
            dropdown.style.display = 'none';
            dropdown.innerHTML = '';
          }
        } catch (e) {
          dropdown.style.display = 'none';
        }
      }, 300);
    });
  }

  /**
   * Show autocomplete results in inline popup dropdown
   */
  function showInlineAutocompleteResults(dropdown, input, results) {
    dropdown.innerHTML = results.map(item => {
      const text = typeof item === 'string' ? item : (item.description || item.address || item.text || JSON.stringify(item));
      return `<div class="homesage-autocomplete-item" title="${escapeHtml(text)}">${escapeHtml(text)}</div>`;
    }).join('');

    dropdown.style.display = 'block';

    dropdown.querySelectorAll('.homesage-autocomplete-item').forEach(el => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        input.value = el.textContent;
        dropdown.style.display = 'none';
        dropdown.innerHTML = '';
        input.focus();
      });
    });
  }

  /**
   * Hide autocomplete dropdown in inline popup
   */
  function hideInlineAutocomplete(popup) {
    const dropdown = popup?.querySelector('.homesage-autocomplete-dropdown');
    if (dropdown) {
      dropdown.style.display = 'none';
      dropdown.innerHTML = '';
    }
  }

  /**
   * Handle click outside popup to close it
   */
  function handleClickOutside(event) {
    if (activePopup && !activePopup.contains(event.target) &&
        !event.target.closest('.homesage-icon-wrapper')) {
      closePopup();
      document.removeEventListener('click', handleClickOutside);
      clickOutsideRegistered = false;
    }
  }

  /**
   * Run full property report
   * Checks subscription/free limit before redirecting
   */
  async function runReport(address) {
    // Show loading state on run report button
    const runBtn = activePopup?.querySelector('#homesage-run-report');
    const searchBtn = activePopup?.querySelector('#homesage-search-btn');
    if (runBtn) { runBtn.disabled = true; runBtn.textContent = 'Generating report...'; }
    if (searchBtn) { searchBtn.disabled = true; searchBtn.textContent = 'Generating report...'; }

    try {
      // Check subscription status
      const subResult = await safeSendMessage({ action: 'checkSubscription' });
      if (!subResult) return;
      log('[HomeSage] Subscription check for report:', subResult);

      // Handle free users
      if (subResult.isFreeUser) {
        if (subResult.freeReportsRemaining <= 0) {
          showFreeLimitReachedMessage();
          return;
        }

        log('[HomeSage] Free report used, redirecting...');
      }

      // Handle paid users - check if they have enough credits
      if (subResult.hasSubscription) {
        if (subResult.remainingCredits < HOMESAGE_REPORT_CREDITS_COST) {
          showInsufficientCreditsMessage(subResult.remainingCredits);
          return;
        }
        log('[HomeSage] Paid user with sufficient credits, redirecting...');
      }

      // Generate report token and redirect
      const reportResult = await safeSendMessage({ action: 'runReport', address, freeUser: subResult.isFreeUser === true });

      if (!reportResult || !reportResult.success) {
        console.error('[HomeSage] Report generation failed:', reportResult?.error);
        // Restore buttons on error
        if (runBtn) { runBtn.disabled = false; runBtn.textContent = 'Run Full Property Report'; }
        if (searchBtn) { searchBtn.disabled = false; searchBtn.textContent = 'Run Full Property Report'; }
        // Show appropriate message in popup
        if (activePopup) {
          const content = activePopup.querySelector('.homesage-popup-content');
          if (content) {
            const isNotFound = reportResult?.error && reportResult.error.toLowerCase().includes('not found');
            if (isNotFound) {
              content.innerHTML = `
                <div style="text-align: center; padding: 20px;">
                  <svg width="48" height="48" viewBox="0 0 48 48" fill="none" style="display: block; margin: 0 auto 12px;">
                    <circle cx="24" cy="24" r="20" stroke="#E8A317" stroke-width="2.5" fill="none"/>
                    <line x1="24" y1="14" x2="24" y2="28" stroke="#E8A317" stroke-width="2.5" stroke-linecap="round"/>
                    <circle cx="24" cy="34" r="1.5" fill="#E8A317"/>
                  </svg>
                  <p style="color: #333; font-weight: 600; font-size: 15px; margin: 0 0 6px;">Address not found</p>
                  <p style="color: #666; font-size: 13px; margin: 0;">This address is not in our database.</p>
                </div>
              `;
            } else {
              content.innerHTML = `
                <div style="text-align: center; padding: 20px;">
                  <p style="color: #dc3545; font-weight: 500;">Failed to generate report</p>
                  <p style="color: #666; font-size: 13px; margin-top: 8px;">${reportResult?.error || 'Please try again later.'}</p>
                </div>
              `;
            }
          }
        }
        return;
      }

      // Close popup
      closePopup();

    } catch (error) {
      console.error('[HomeSage] Error running report:', error);
      // Restore buttons on error
      if (runBtn) { runBtn.disabled = false; runBtn.textContent = 'Run Full Property Report'; }
      if (searchBtn) { searchBtn.disabled = false; searchBtn.textContent = 'Run Full Property Report'; }
      closePopup();
    }
  }

  /**
   * Show insufficient credits message for paid users
   */
  function showInsufficientCreditsMessage(currentCredits) {
    if (!activePopup) return;
    
    const content = activePopup.querySelector('.homesage-popup-content');
    const manual = activePopup.querySelector('.homesage-popup-manual');
    let creditsState = activePopup.querySelector('.homesage-credits-state');
    
    // Hide other states
    if (content) content.style.display = 'none';
    if (manual) manual.style.display = 'none';
    
    // Create insufficient credits state if it doesn't exist
    if (!creditsState) {
      creditsState = document.createElement('div');
      creditsState.className = 'homesage-credits-state';
      activePopup.appendChild(creditsState);
    }
    
    creditsState.innerHTML = `
      <div class="homesage-credits-message">
        <svg class="homesage-icon-credit" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="10"></circle>
          <path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"></path>
          <path d="M12 18V6"></path>
        </svg>
        <h3>Insufficient credits</h3>
        <p>You need ${HOMESAGE_REPORT_CREDITS_COST} credits to run a report.<br>Your balance: <strong>${Number(currentCredits).toLocaleString()} credits</strong></p>
      </div>
      <button class="homesage-popup-btn homesage-btn-primary" id="homesage-purchase-btn">
        Purchase Credits
      </button>
      <button class="homesage-popup-btn homesage-btn-link" id="homesage-credits-back-btn">
        ← Back
      </button>
    `;
    
    // Add event listeners
    creditsState.querySelector('#homesage-purchase-btn').addEventListener('click', () => {
      window.open(`${HOMESAGE_API_BASE_URL}/subscription`, '_blank');
    });
    
    creditsState.querySelector('#homesage-credits-back-btn').addEventListener('click', () => {
      creditsState.style.display = 'none';
      if (content) content.style.display = 'block';
      const runBtn = activePopup?.querySelector('#homesage-run-report');
      if (runBtn) { runBtn.disabled = false; runBtn.textContent = 'Run Full Property Report'; }
    });
    
    creditsState.style.display = 'block';
  }

  /**
   * Show free limit reached message
   */
  function showFreeLimitReachedMessage() {
    if (!activePopup) return;
    
    const content = activePopup.querySelector('.homesage-popup-content');
    const manual = activePopup.querySelector('.homesage-popup-manual');
    let limitState = activePopup.querySelector('.homesage-limit-state');
    
    // Hide other states
    if (content) content.style.display = 'none';
    if (manual) manual.style.display = 'none';
    
    // Create limit reached state if it doesn't exist
    if (!limitState) {
      limitState = document.createElement('div');
      limitState.className = 'homesage-limit-state';
      limitState.innerHTML = `
        <div class="homesage-limit-message">
          <svg class="homesage-icon-alert" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
            <line x1="12" y1="9" x2="12" y2="13"></line>
            <circle cx="12" cy="17" r="0.5" fill="currentColor"></circle>
          </svg>
          <h3>Monthly limit reached</h3>
          <p>You've used all 3 free reports this month. Upgrade to Pro for unlimited reports.</p>
        </div>
        <button class="homesage-popup-btn homesage-btn-primary" id="homesage-upgrade-btn">
          Upgrade to Pro
        </button>
        <button class="homesage-popup-btn homesage-btn-link" id="homesage-limit-back-btn">
          ← Back
        </button>
      `;
      activePopup.appendChild(limitState);
      
      // Add event listeners
      limitState.querySelector('#homesage-upgrade-btn').addEventListener('click', () => {
        window.open(`${HOMESAGE_API_BASE_URL}/subscription`, '_blank');
      });
      
      limitState.querySelector('#homesage-limit-back-btn').addEventListener('click', () => {
        limitState.style.display = 'none';
        if (content) content.style.display = 'block';
        const runBtn = activePopup?.querySelector('#homesage-run-report');
        if (runBtn) { runBtn.disabled = false; runBtn.textContent = 'Run Full Property Report'; }
      });
    }
    
    limitState.style.display = 'block';
  }

  /**
   * Debounce helper
   */
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // openInlinePopup listener is handled in the consolidated message listener above

  /**
   * Open popup centered on screen (for right-click menu)
   */
  function openPopupCentered(address) {
    // Calculate center position
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    const popupWidth = 320;
    const popupHeight = 400; // Approximate height
    
    const left = window.scrollX + (viewportWidth - popupWidth) / 2;
    const top = window.scrollY + (viewportHeight - popupHeight) / 2;
    
    // Use the existing openPopup function with calculated position
    openPopup(address, { top, left });
  }

  // ==================== FAVORITES MANAGEMENT ====================

  /**
   * Check if an address is in favorites (local storage)
   */
  async function checkIfFavorited(address) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(['favorites'], (result) => {
          const favorites = result?.favorites || [];
          const normalized = address.toLowerCase().trim();
          const isFavorited = favorites.some(fav => fav.address.toLowerCase().trim() === normalized);
          resolve(isFavorited);
        });
      } catch (e) {
        resolve(false);
      }
    });
  }

  /**
   * Add address to favorites (local + server sync)
   */
  async function addToFavorites(address, propertyId = null) {
    // Save to local storage first
    const localSaved = await new Promise((resolve) => {
      try {
        chrome.storage.local.get(['favorites'], (result) => {
          const favorites = result?.favorites || [];
          const normalized = address.toLowerCase().trim();
          
          const exists = favorites.some(fav => fav.address.toLowerCase().trim() === normalized);
          if (!exists) {
            favorites.push({
              address: address,
              property_id: propertyId,
              addedAt: new Date().toISOString()
            });
            chrome.storage.local.set({ favorites }, () => {
              log('[HomeSage] Added to local favorites:', address);
              resolve(true);
            });
          } else {
            resolve(false);
          }
        });
      } catch (e) {
        resolve(false);
      }
    });

    // Also sync to server via background script
    try {
      const saveResult = await safeSendMessage({ action: 'saveFavorite', address, propertyId });
      if (saveResult?.success && saveResult.data) {
        const saveData = saveResult.data;
        log('[HomeSage] Synced favorite to server:', address, saveData);
        // Store the saved record ID from server for future DELETE
        if (saveData.id || saveData.saved_id) {
          chrome.storage.local.get(['favorites'], (result) => {
            const favorites = result.favorites || [];
            const normalized = address.toLowerCase().trim();
            const fav = favorites.find(f => f.address.toLowerCase().trim() === normalized);
            if (fav) {
              fav.saved_id = saveData.id || saveData.saved_id;
              chrome.storage.local.set({ favorites });
            }
          });
        }
      } else {
        log('[HomeSage] Failed to sync favorite to server:', saveResult?.error);
      }
    } catch (error) {
      console.error('[HomeSage] Error syncing favorite to server:', error);
    }

    return localSaved;
  }

  /**
   * Remove address from favorites (local + server sync)
   */
  async function removeFromFavorites(address, propertyId = null) {
    // Remove from local storage first
    const localRemoved = await new Promise((resolve) => {
      try {
        chrome.storage.local.get(['favorites'], (result) => {
          const favorites = result?.favorites || [];
          const normalized = address.toLowerCase().trim();
          
          const removedFav = favorites.find(fav => 
            fav.address.toLowerCase().trim() === normalized
          );
          
          const newFavorites = favorites.filter(fav => 
            fav.address.toLowerCase().trim() !== normalized
          );
          
          chrome.storage.local.set({ favorites: newFavorites }, () => {
            log('[HomeSage] Removed from local favorites:', address);
            resolve(removedFav);
          });
        });
      } catch (e) {
        resolve(null);
      }
    });

    // Also sync to server via background script
    try {
      // DELETE endpoint uses property_id as its URL lookup field, not the saved-record PK.
      const deleteId = propertyId || localRemoved?.property_id || localRemoved?.saved_id;
      log('[HomeSage] Deleting from server with id:', deleteId);
      if (deleteId) {
        const removeResult = await safeSendMessage({ action: 'removeFavorite', propertyId: deleteId });
        if (removeResult?.success) {
          log('[HomeSage] Removed favorite from server:', address);
        } else {
          log('[HomeSage] Failed to remove favorite from server:', removeResult?.error);
        }
      }
    } catch (error) {
      console.error('[HomeSage] Error removing favorite from server:', error);
    }

    return !!localRemoved;
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();