/**
 * HomeSage.ai Background Service Worker
 * Handles API calls, authentication, and context menus
 */

// Set to true during local development to enable verbose console logging.
const DEV_MODE = false;
const log = (...args) => { if (DEV_MODE) console.log(...args); };

// Context menu ID
const CONTEXT_MENU_ID = 'homesage-lookup';
const API_BASE_URL = 'https://developers.homesage.ai';
const REPORT_CREDITS_COST = 15;
const FREE_REPORT_LIMIT = 3;

let autoCompleteAbortController = null;

/**
 * Initialize extension on install
 */
chrome.runtime.onInstalled.addListener((details) => {
  log('[HomeSage] Extension installed/updated:', details.reason);

  // Set default display mode
  chrome.storage.local.get(['displayMode'], (result) => {
    if (!result.displayMode) {
      chrome.storage.local.set({ displayMode: 'permanent' });
    }
  });

  // Create context menu
  createContextMenu();

  // On FIRST install only, inject into pre-loaded tabs
  // This is safe because there's no old content script to conflict with
  // We don't do this on 'update' because old scripts with dead contexts cause issues
  if (details.reason === 'install') {
    injectIntoExistingTabs();
  }
});

/**
 * Inject content scripts into all existing HTTP tabs.
 * Only called on fresh install — no old script conflicts possible.
 */
async function injectIntoExistingTabs() {
  try {
    const manifest = chrome.runtime.getManifest();
    const cs = manifest.content_scripts?.[0];
    if (!cs) return;

    const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });

    for (const tab of tabs) {
      try {
        if (cs.css?.length) {
          await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: cs.css });
        }
        if (cs.js?.length) {
          await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: cs.js });
        }
        log('[HomeSage] Injected into tab:', tab.id);
      } catch (e) {
        // Expected to fail on restricted pages
      }
    }
  } catch (e) {
    log('[HomeSage] Injection error:', e.message);
  }
}

/**
 * Create right-click context menu
 */
function createContextMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: CONTEXT_MENU_ID,
      title: 'Look up on HomeSage.ai',
      contexts: ['selection']
    });
  });
}

/**
 * Handle context menu clicks
 */
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === CONTEXT_MENU_ID && info.selectionText) {
    const selectedText = info.selectionText.trim();

    // Send message to content script to open inline popup
    chrome.tabs.sendMessage(tab.id, {
      action: 'openInlinePopup',
      address: selectedText
    }).catch(async (error) => {
      log('[HomeSage] Could not send to content script, generating report');
      // Fallback: generate report token and open
      const result = await handleRunReport(selectedText);
      if (!result.success) {
        console.error('[HomeSage] Failed to open report:', result.error);
      }
    });
  }
});

/**
 * Handle messages from content scripts and popup
 */
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  log('[HomeSage] Message received:', message.action, message);

  switch (message.action) {
    case 'getPropertyData':
      log('[HomeSage] Getting property data for:', message.address);
      handleGetPropertyData(message.address)
        .then(data => {
          log('[HomeSage] Property data result:', data);
          sendResponse({ success: true, data });
        })
        .catch(error => {
          console.error('[HomeSage] Property data error:', error);
          sendResponse({ success: false, error: error.message });
        });
      return true;

    case 'autoComplete':
      handleAutoComplete(message.input)
        .then(results => sendResponse({ success: true, results }))
        .catch(error => sendResponse({ success: false, error: error.message, results: [] }));
      return true;

    case 'checkAuth':
      handleCheckAuth()
        .then(result => {
          log('[HomeSage] Auth check result:', result);
          sendResponse(result);
        })
        .catch(error => {
          console.error('[HomeSage] Auth check error:', error);
          sendResponse({ authenticated: false, error: error.message });
        });
      return true;

    case 'checkSubscription':
      handleCheckSubscription()
        .then(result => {
          log('[HomeSage] Subscription check result:', result);
          sendResponse(result);
        })
        .catch(error => {
          console.error('[HomeSage] Subscription check error:', error);
          sendResponse({ success: false, error: error.message });
        });
      return true;

    case 'syncFavorites':
      syncFavoritesWithServer()
        .then(result => {
          log('[HomeSage] Favorites sync result:', result);
          sendResponse(result);
        })
        .catch(error => {
          console.error('[HomeSage] Favorites sync error:', error);
          sendResponse({ success: false, error: error.message });
        });
      return true;

    case 'openSettings':
      chrome.runtime.openOptionsPage();
      sendResponse({ success: true });
      break;

    case 'setSelectedAddress':
      chrome.storage.local.set({ selectedAddress: message.address });
      sendResponse({ success: true });
      break;

    case 'runReport':
      handleRunReport(message.address, message.freeUser || false)
        .then(result => sendResponse(result))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;

    case 'saveFavorite':
      handleSaveFavorite(message.address, message.propertyId)
        .then(result => sendResponse(result))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;

    case 'removeFavorite':
      handleRemoveFavorite(message.propertyId)
        .then(result => sendResponse(result))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;

    default:
      log('[HomeSage] Unknown message action:', message.action);
      sendResponse({ success: false, error: 'Unknown action' });
  }
});

/**
 * Handle address autocomplete
 * Calls /api/properties/auto-complete/ with user input
 */
async function handleAutoComplete(input) {
  if (!input || input.trim().length < 3) {
    return [];
  }

  let acTimeoutId = null;
  try {
    const token = await getAuthToken();
    if (!token) return [];

    if (autoCompleteAbortController) {
      autoCompleteAbortController.abort();
    }
    autoCompleteAbortController = new AbortController();
    acTimeoutId = setTimeout(() => autoCompleteAbortController.abort(), 10000);

    const encodedInput = encodeURIComponent(input.trim());
    const response = await fetch(`${API_BASE_URL}/api/properties/auto-complete/?input=${encodedInput}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      signal: autoCompleteAbortController.signal
    });
    clearTimeout(acTimeoutId); autoCompleteAbortController = null;

    log('[HomeSage] Autocomplete API status:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      log('[HomeSage] Autocomplete API error body:', errorText);
      return [];
    }

    const data = await response.json();
    log('[HomeSage] Autocomplete API response:', JSON.stringify(data));
    if (Array.isArray(data)) return data;
    return data.data || data.results || data.suggestions || data.predictions || [];
  } catch (error) {
    clearTimeout(acTimeoutId); autoCompleteAbortController = null;
    if (error.name === 'AbortError') return [];
    log('[HomeSage] Autocomplete error:', error.message);
    return [];
  }
}

/**
 * Wraps fetch with an AbortController timeout.
 * @param {string} url
 * @param {Object} options - fetch options (signal will be overwritten)
 * @param {number} [timeoutMs=10000]
 * @returns {Promise<Response>}
 */
async function fetchWithTimeout(url, options, timeoutMs = 10000) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    clearTimeout(timeoutId);
    return response;
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
}

/**
 * Get property data from the backend API
 * Calls /api/properties/basic-info/ for lightweight property preview
 */
async function handleGetPropertyData(address) {
  log('[HomeSage] Getting property data for:', address);
  const notFound = () => ({ address, sqft: '--', beds: '--', baths: '--', found: false });

  try {
    const token = await getAuthToken();

    if (!token) {
      log('[HomeSage] Not authenticated, returning placeholder data');
      return notFound();
    }

    const encodedAddress = encodeURIComponent(address);
    const response = await fetchWithTimeout(`${API_BASE_URL}/api/properties/basic-info/?property_address=${encodedAddress}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      log('[HomeSage] Property API error:', response.status);
      return notFound();
    }

    const data = await response.json();
    log('[HomeSage] Property data received:', data);

    return {
      address: data.address || address,
      sqft: data.sqft || '--',
      beds: data.beds || '--',
      baths: data.baths || '--',
      property_id: data.property_id,
      found: data.found || false
    };

  } catch (error) {
    console.error('[HomeSage] Error fetching property data:', error);
    return notFound();
  }
}

/**
 * Check authentication status
 * Uses id_token from developers.homesage.ai cookie
 */
async function handleCheckAuth() {
  log('[HomeSage] Checking authentication...');

  try {
    const token = await getAuthToken();

    if (!token) {
      log('[HomeSage] Not authenticated - no id_token found');
      return {
        authenticated: false,
        user: null
      };
    }

    // Token found - decode and validate
    log('[HomeSage] Token found, validating...');

    // Decode JWT to get basic user info and check expiry
    let userInfo = null;
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));

      // Check if token has expired
      if (payload.exp && payload.exp * 1000 < Date.now()) {
        log('[HomeSage] Token has expired');
        return {
          authenticated: false,
          user: null,
          error: 'Token expired'
        };
      }

      userInfo = {
        sub: payload.sub,
        email: payload.email || null,
        exp: payload.exp
      };
    } catch (e) {
      log('[HomeSage] Token parsing failed:', e.message);
      return { authenticated: false, user: null, error: 'Invalid token format' };
    }

    log('[HomeSage] User is authenticated');
    return {
      authenticated: true,
      user: userInfo
    };
  } catch (error) {
    console.error('[HomeSage] Auth check failed:', error);
    return {
      authenticated: false,
      error: error.message
    };
  }
}

/**
 * Check subscription status
 * Calls /api/subscription/usage-info/ to determine user's plan
 * Backend returns different formats for paid users, free users, and expired users
 */
async function handleCheckSubscription() {
  log('[HomeSage] Checking subscription status...');

  try {
    const token = await getAuthToken();

    if (!token) {
      return {
        success: false,
        error: 'Not authenticated',
        hasSubscription: false
      };
    }

    let response;
    try {
      response = await fetchWithTimeout(`${API_BASE_URL}/api/subscription/usage-info/`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
    } catch (fetchError) {
      if (fetchError.name === 'AbortError') return { success: false, error: 'Request timed out', hasSubscription: false };
      throw fetchError;
    }

    log('[HomeSage] Subscription API response status:', response.status);

    if (response.status === 401) {
      return {
        success: false,
        error: 'Not authenticated',
        hasSubscription: false
      };
    }

    let data;
    try {
      data = await response.json();
      log('[HomeSage] Subscription API data:', JSON.stringify(data));
    } catch (parseError) {
      console.error('[HomeSage] Failed to parse subscription response:', parseError);
      return {
        success: false,
        error: 'Invalid server response',
        hasSubscription: false
      };
    }

    if (response.status === 400) {
      // Error response - could be expired subscription, no subscription, or other error
      if (data.subscription_status === 'canceled') {
        return {
          success: true,
          hasSubscription: false,
          isFreeUser: false,
          isExpired: true,
          message: data.error || 'Subscription expired'
        };
      }

      // "No subscription plan found" means free user - use local tracking
      if (data.error && data.error.toLowerCase().includes('no subscription plan found')) {
        const freeUsage = await getFreeUsageThisMonth();
        const freeReportsRemaining = Math.max(0, FREE_REPORT_LIMIT - freeUsage);

        log('[HomeSage] Free user (no subscription) - local usage:', freeUsage, 'remaining:', freeReportsRemaining);

        return {
          success: true,
          hasSubscription: false,
          isFreeUser: true,
          freeReportsUsed: freeUsage,
          freeReportsRemaining: freeReportsRemaining,
          freeReportsLimit: FREE_REPORT_LIMIT
        };
      }

      // Other 400 error
      return {
        success: false,
        error: data.error || 'Subscription check failed',
        hasSubscription: false
      };
    }

    if (response.ok) {
      // Check if it's a paid user or free user based on response
      if (data.has_subscription) {
        // Paid user with subscription
        const totalCredits = data.total_credits ?? 0;
        const usedCredits = data.used_credits ?? 0;
        const remainingCredits = data.remaining_credits ?? 0;

        log('[HomeSage] Paid user - credits:', remainingCredits);

        return {
          success: true,
          hasSubscription: true,
          isFreeUser: false,
          totalCredits: totalCredits,
          usedCredits: usedCredits,
          remainingCredits: remainingCredits,
          canRunReport: remainingCredits >= REPORT_CREDITS_COST  // 15 credits for extension reports
        };
      }

      if (data.is_free_user) {
        // Free user - server tracks usage
        log('[HomeSage] Free user - reports remaining:', data.free_reports_remaining);

        return {
          success: true,
          hasSubscription: false,
          isFreeUser: true,
          freeReportsUsed: data.free_reports_used ?? 0,
          freeReportsRemaining: data.free_reports_remaining ?? FREE_REPORT_LIMIT,
          freeReportsLimit: data.free_reports_limit ?? FREE_REPORT_LIMIT
        };
      }

      // Unknown response format
      log('[HomeSage] Unknown response format:', data);
      return {
        success: false,
        error: 'Unknown subscription status',
        hasSubscription: false
      };
    }

    // Other error
    return {
      success: false,
      error: `API error: ${response.status}`,
      hasSubscription: false
    };

  } catch (error) {
    console.error('[HomeSage] Subscription check error:', error);
    return {
      success: false,
      error: error.message,
      hasSubscription: false
    };
  }
}

/**
 * Get free usage count for current month
 */
async function getFreeUsageThisMonth() {
  return new Promise((resolve) => {
    const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM format

    chrome.storage.local.get(['freeUsage'], (result) => {
      const usage = result.freeUsage || {};
      resolve(usage[currentMonth] || 0);
    });
  });
}

/**
 * Increment free usage count for current month
 */
async function incrementFreeUsage() {
  return new Promise((resolve) => {
    const currentMonth = new Date().toISOString().slice(0, 7);

    chrome.storage.local.get(['freeUsage'], (result) => {
      const usage = result.freeUsage || {};
      usage[currentMonth] = (usage[currentMonth] || 0) + 1;

      chrome.storage.local.set({ freeUsage: usage }, () => {
        resolve(usage[currentMonth]);
      });
    });
  });
}

/**
 * Sync favorites with server saved properties
 * Fetches saved properties from platform and updates local storage
 */
async function syncFavoritesWithServer() {
  log('[HomeSage] Syncing favorites with server...');

  try {
    const token = await getAuthToken();

    if (!token) {
      log('[HomeSage] Not authenticated, skipping sync');
      return { success: false, error: 'Not authenticated' };
    }

    let response;
    try {
      response = await fetchWithTimeout(`${API_BASE_URL}/api/properties/saved/`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
    } catch (fetchError) {
      if (fetchError.name === 'AbortError') return { success: false, error: 'Request timed out' };
      throw fetchError;
    }

    log('[HomeSage] Saved properties API status:', response.status);

    if (!response.ok) {
      log('[HomeSage] Failed to fetch saved properties:', response.status);
      return { success: false, error: `API error: ${response.status}` };
    }

    const serverData = await response.json();
    log('[HomeSage] Server saved properties:', serverData);

    // Normalize server data to our favorites format
    // Adapt based on the actual API response structure
    let serverFavorites = [];

    // Handle different possible response formats
    const properties = Array.isArray(serverData) ? serverData : (serverData.results || serverData.properties || serverData.saved_properties || []);

    // Log the raw shape of the first item so we can verify which field holds the
    // saved-record primary key (the one needed for DELETE /api/properties/saved/<id>/).
    if (properties.length > 0) {
      log('[HomeSage] Saved property raw keys:', Object.keys(properties[0]));
      log('[HomeSage] Saved property sample:', JSON.stringify(properties[0]));
    }

    serverFavorites = properties.map(prop => ({
      address: prop.address || prop.property_address || '',
      property_id: prop.property_id || null,
      // The saved record ID used for DELETE /api/properties/saved/<id>/
      // Try every field name the API might use for the primary key of the saved record.
      saved_id: prop.saved_id || prop.id || prop.pk || prop.saved_property_id || prop.record_id || null,
      addedAt: prop.created_at || prop.saved_at || new Date().toISOString()
    })).filter(fav => fav.address); // Remove entries without an address

    // Log what we resolved so any missing saved_id is immediately visible.
    log('[HomeSage] Resolved favorites (saved_id check):', serverFavorites.map(f => ({ address: f.address, saved_id: f.saved_id, property_id: f.property_id })));

    // Update local storage with server data
    await new Promise((resolve) => {
      chrome.storage.local.set({ favorites: serverFavorites }, () => {
        log('[HomeSage] Local favorites updated from server:', serverFavorites.length, 'items');
        resolve();
      });
    });

    return { success: true, count: serverFavorites.length, favorites: serverFavorites };

  } catch (error) {
    console.error('[HomeSage] Favorites sync error:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Save a property to favorites on the server
 */
async function handleSaveFavorite(address, propertyId) {
  const token = await getAuthToken();
  if (!token) return { success: false, error: 'Not authenticated' };

  try {
    const response = await fetchWithTimeout(`${API_BASE_URL}/api/properties/save/`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ property_id: propertyId || '', address })
    });
    if (!response.ok) return { success: false, error: `API error: ${response.status}` };
    const data = await response.json();
    // Log raw POST response so we can verify the saved-record PK field name
    log('[HomeSage] Save favorite POST raw keys:', Object.keys(data));
    log('[HomeSage] Save favorite POST response:', JSON.stringify(data));
    return { success: true, data };
  } catch (error) {
    if (error.name === 'AbortError') return { success: false, error: 'Request timed out' };
    return { success: false, error: error.message };
  }
}

/**
 * Remove a property from favorites on the server
 */
async function handleRemoveFavorite(propertyId) {
  if (!propertyId) return { success: false, error: 'No property ID provided' };
  const token = await getAuthToken();
  if (!token) return { success: false, error: 'Not authenticated' };

  // The DELETE endpoint uses property_id as the URL lookup field.
  const deleteUrl = `${API_BASE_URL}/api/properties/saved/${propertyId}/`;
  log('[HomeSage] DELETE favorite URL:', deleteUrl);

  try {
    const response = await fetchWithTimeout(deleteUrl, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    log('[HomeSage] DELETE response status:', response.status);
    if (response.ok) return { success: true };
    let body = '';
    try { body = await response.text(); } catch (_) {}
    log('[HomeSage] DELETE failed body:', body);
    return { success: false, error: `API error: ${response.status}` };
  } catch (error) {
    if (error.name === 'AbortError') return { success: false, error: 'Request timed out' };
    return { success: false, error: error.message };
  }
}

/**
 * Run full property report
 */
async function handleRunReport(address, freeUser = false) {
  log('[HomeSage] Running report for:', address);

  try {
    const token = await getAuthToken();

    if (!token) {
      console.error('[HomeSage] Not authenticated');
      return { success: false, error: 'Not authenticated' };
    }

    // First, get the property ID from basic-info
    const propertyData = await handleGetPropertyData(address);
    log('[HomeSage] Property data for report:', propertyData);

    if (!propertyData.property_id) {
      log('[HomeSage] Address not found in database:', address);
      return { success: false, error: 'Property not found in database' };
    }

    // Call the token generation endpoint
    // POST /api/report/generate/token/ with property_address
    // X-Client-Source header identifies this as extension request (15 credits vs 30 for platform)
    let response;
    try {
      response = await fetchWithTimeout(`${API_BASE_URL}/api/report/generate/token/`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'X-Client-Source': 'browser-extension'
        },
        body: JSON.stringify({
          address: JSON.stringify({
            text: address,
            address: propertyData.address || address,
            id: propertyData.property_id
          })
        })
      });
    } catch (fetchError) {
      if (fetchError.name === 'AbortError') return { success: false, error: 'Request timed out' };
      throw fetchError;
    }

    if (!response.ok) {
      let errorMessage = 'Failed to generate report';
      try {
        const errorData = await response.json();
        errorMessage = errorData.error || errorMessage;
      } catch {
        // Non-JSON error body (e.g. HTML 500 page) — keep generic message
      }
      console.error('[HomeSage] Token generation failed:', response.status, errorMessage);
      return { success: false, error: errorMessage };
    }

    const data = await response.json();
    if (!data.token) {
      console.error('[HomeSage] No token in report response:', data);
      return { success: false, error: data.error || 'No report token received from server' };
    }
    const reportToken = data.token;

    // Redirect to report page with JWT token
    const reportUrl = `${API_BASE_URL}/report?token=${reportToken}`;
    chrome.tabs.create({ url: reportUrl });

    if (freeUser) {
      await incrementFreeUsage();
      log('[HomeSage] Free usage incremented after successful report open');
    }

    return { success: true, url: reportUrl };

  } catch (error) {
    console.error('[HomeSage] Error generating report:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Get auth token (id_token) from cookies
 * Used for all API requests per handoff document
 */
function getAuthToken() {
  return new Promise((resolve) => {
    chrome.cookies.get(
      { url: API_BASE_URL, name: 'id_token' },
      (cookie) => {
        if (!cookie) {
          log('[HomeSage] Cookie check result: not found');
          return resolve(null);
        }
        // Check JWT expiry so all callers treat an expired token the same as missing.
        try {
          const payload = JSON.parse(atob(cookie.value.split('.')[1]));
          if (payload.exp && payload.exp * 1000 < Date.now()) {
            log('[HomeSage] id_token has expired');
            return resolve(null);
          }
        } catch (e) {
          log('[HomeSage] Could not parse id_token JWT:', e.message);
          return resolve(null);
        }
        log('[HomeSage] Cookie check result: found and valid');
        resolve(cookie.value);
      }
    );
  });
}

/**
 * Listen for storage changes
 */
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && changes.displayMode) {
    log('[HomeSage] Display mode changed:', changes.displayMode.newValue);

    // Update context menu visibility based on mode
    chrome.contextMenus.update(CONTEXT_MENU_ID, {
      visible: changes.displayMode.newValue === 'rightclick'
    });
  }
});
